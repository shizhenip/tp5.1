-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : tp5
-- 
-- Part : #1
-- Date : 2017-11-23 10:19:11
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `system_user`
-- -----------------------------
DROP TABLE IF EXISTS `system_user`;
CREATE TABLE `system_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `deparment_id` varchar(64) DEFAULT NULL COMMENT '部门ID',
  `realname` varchar(50) DEFAULT NULL COMMENT '真实姓名',
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '登录账号',
  `password` char(32) NOT NULL DEFAULT '' COMMENT '登录密码',
  `mail` varchar(32) DEFAULT NULL COMMENT '联系邮箱',
  `phone` varchar(16) DEFAULT NULL COMMENT '联系手机号',
  `desc` varchar(255) DEFAULT '' COMMENT '备注说明',
  `login_num` bigint(20) unsigned DEFAULT '0' COMMENT '登录次数',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `authorize` varchar(255) DEFAULT NULL COMMENT '所持权限',
  `is_deleted` tinyint(1) unsigned DEFAULT '0' COMMENT '删除状态(1:删除,0:未删)',
  `login_at` int(11) DEFAULT NULL COMMENT '最后登录时间',
  `create_at` int(11) DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_system_user_username` (`phone`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10001 DEFAULT CHARSET=utf8 COMMENT='系统用户表';

-- -----------------------------
-- Records of `system_user`
-- -----------------------------
INSERT INTO `system_user` VALUES ('10000', '5', '超级管理员', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '11111@qq.com', '13925526141', '1', '12914', '1', '2', '0', '1503976031', '1503976031');
