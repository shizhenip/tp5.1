<?php

namespace app\index\controller;

use think\Controller;
use think\Db;

/**
 * 留言
 * Class LeaveWord
 * @package app\index\controller
 * @date 2017/12/01 18:12
 */
class Message extends Controller
{

    /**
     * 指定当前数据表
     * @var string
     */
    public $table = 'blog_messages';

    /**
     * 填写留言
     */
    public function index()
    {
        $get = $this->request->get();
        $db = Db::name($this->table)->alias('m')
            ->join('blog_user u', 'u.id=m.uid', 'LEFT')
            ->where('m.status', 1)
            ->field('m.*,u.username,u.head_img')
            ->order('m.id desc');
        $list = $db->paginate(3, true, ['query' => $get]);
        $page = preg_replace(['/上一页/', '/下一页/'], ['<button class="layui-btn layui-btn-normal">上一页</button>', '<button class="layui-btn layui-btn-normal">下一页</button>'], $list->render());
        $this->assign([
            'list' => $list,
            'page' => $page,
        ]);
        return view();
    }
}