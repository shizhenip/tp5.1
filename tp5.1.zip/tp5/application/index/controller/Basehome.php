<?php

namespace app\index\controller;

use think\Controller;

/**
 * 入口文件
 * Class Basehome
 * @package app\index\controller
 * @date 2018/07/01 18:12
 */
class Basehome extends Controller
{
    public function initialize()
    {

    }

}