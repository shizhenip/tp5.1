<?php

namespace app\index\controller;

use think\Controller;
use think\Db;

/**
 * 用户登录注册
 * Class User
 * @package app\index\controller
 * @date 2018/07/01 18:12
 */
class User extends Controller
{
    public $table = 'blog_user';

    /**
     * 用户登录
     */
    public function index()
    {
        if ($this->request->isPost()) {
            $post = $this->request->post();
            if (!isset($post['username']) || !isset($post['password'])) return json(['code' => 5, 'msg' => '提交信息有误！']);
            if (empty($post['username']) || empty($post['password'])) return json(['code' => 5, 'msg' => '提交信息有误！']);
            $info = Db::name($this->table)->where('is_deleted', 0)->where('phone', $post['username'])->find();
            if (empty($info)) return json(['code' => 5, 'msg' => '账号不存在！']);
            if ($info['status'] == 0) return json(['code' => 5, 'msg' => '账号已禁用！']);
            if ($info['password'] !== password($post['password'])) return json(['code' => 5, 'msg' => '账号密码错误！']);
            Db::name($this->table)->where('id', $info['id'])->inc('login_num')->update(['login_at' => time()]);
            session('userInfo', $info);
            session('userInfoSign', self::sign($info));
            return json(['code' => 1, 'msg' => '登录成功...', 'url' => url('/userInfo')]);
        }
        return view();
    }

    /**
     * 注册账号
     */
    public function register()
    {
        if ($this->request->isPost()) {
            $post = $this->request->post();
            if (!isset($post['username']) || !isset($post['phone']) || !isset($post['password']) || !isset($post['password2'])) return json(['code' => 5, 'msg' => '提交信息有误！']);
            if (empty($post['username']) || empty($post['phone']) || empty($post['password']) || empty($post['password2'])) return json(['code' => 5, 'msg' => '提交信息有误！']);
            $username = trim($post['username']);
            $phone = trim($post['phone']);
            $password = trim($post['password']);
            $password2 = trim($post['password2']);
            if (mb_strlen($username, 'UTF-8') < 2 || mb_strlen($username, 'UTF-8') > 28) return json(['code' => 5, 'msg' => '昵称不合格！']);
            if (!isPhone($phone)) return json(['code' => 5, 'msg' => '账号必须是正确的手机号码！']);
            if ($password !== $password2) return json(['code' => 5, 'msg' => '确认密码错误！']);
            if (Db::name($this->table)->where('phone', $phone)->count() >= 1) return json(['code' => 5, 'msg' => '账号已被注册！']);
            $data['username'] = $username;
            $data['phone'] = $phone;
            $data['password'] = password($password);
            $data['head_img'] = request()->root(true) . '/static/index/images/head/' . rand(1, 20) . '.jpg';
            $data['create_at'] = time();
            Db::startTrans();
            try {
                $result = Db::name($this->table)->insert($data);
                Db::commit();
            } catch (\Exception $e) {
                Db::rollback();
                $result = 0;
            }
            if ($result !== 1) {
                return json(['code' => 5, 'msg' => '处理中...']);
            } else {
                return json(['code' => 1, 'msg' => '注册成功！', 'data' => $data, 'url' => url('/userInfo')]);
            }
        }
        return view();
    }

    /**
     * 退出
     */
    public function logout()
    {
        session('userInfo', null);
        cookie('userInfo', null);
        return json(['code' => 1, 'msg' => '退出登录成功！', 'url' => '/userInfo.html']);
    }

    /**
     * 生成用户签名
     * @param $data
     * @return string
     */
    protected static function sign($data = [])
    {
        //数据类型检测
        if (!is_array($data)) $data = [];
        ksort($data);//排序
        $code = http_build_query($data);//url编码并生成query字符串
        $sign = sha1($code);//生成签名
        return $sign;
    }
}