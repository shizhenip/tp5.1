<?php

namespace app\index\controller;

use think\Controller;
use think\Db;

/**
 * 首页
 * Class Index
 * @package app\index\controller
 * @date 2018/07/01 18:12
 */
class Index extends Controller
{
    /**
     * 文章列表
     */
    public function index()
    {
        $get = $this->request->get();
        $title = input('title', '', 'string');
        $db = Db::name('blog_article')->where('status', 1)->order('id desc');
        if (isset($get['title']) && !empty(trim($title))) {
            $db->whereLike('title', "%" . trim($title) . "%");
        }
        $list = $db->paginate(2, true, ['query' => $get]);
        $page = preg_replace(['/上一页/', '/下一页/'], ['<button class="layui-btn layui-btn-normal">上一页</button>', '<button class="layui-btn layui-btn-normal">下一页</button>'], $list->render());
        $this->assign([
            'list' => $list,
            'page' => $page,
            'notice' => Db::name('blog_notice')->where('status', 1)->order('create_at desc')->find(),
        ]);
        return view();
    }

    /**
     * 查看公告
     */
    public function lookNtc()
    {
        $id = input('id', '', 'intval');
        $noticeList = Db::name('blog_notice')->where('status', 1)->where('id', $id)->find();
        if (empty($noticeList)) $this->redirect('/home.html');
        Db::name('blog_notice')->where('status', 1)->where('id', $id)->inc('read_num')->update();//增加阅读数
        $is_laud = Db::name('blog_n_laud_record')->where('uid', session('userInfo.id'))->where('laud_id', $id)->count();
        $this->assign([
            'vo' => $noticeList,
            'is_laud' => $is_laud
        ]);
        return view();
    }

    /**
     * 查看文章
     */
    public function lookAtc()
    {
        $get = $this->request->get();
        $id = input('id', '', 'intval');
        $articleList = Db::name('blog_article')->where('status', 1)->where('id', $id)->find();
        if (empty($articleList)) $this->redirect('/home.html');
        Db::name('blog_article')->where('status', 1)->where('id', $id)->inc('read_num')->update();//增加阅读数
        $article_comment_db = Db::name('blog_article_comment')->alias('a')
            ->join('blog_user u', 'u.id=a.uid', 'LEFT')
            ->where('a.act_id', $id)
            ->field('a.*,u.username,u.head_img')
            ->order('a.id desc');//文章评论
        $article_comment = $article_comment_db->paginate(2, true, ['query' => $get]);
        $article_comment_page = preg_replace(['/上一页/', '/下一页/'], ['<button class="layui-btn layui-btn-normal">上一页</button>', '<button class="layui-btn layui-btn-normal">下一页</button>'], $article_comment->render());
        $is_laud = Db::name('blog_a_laud_record')->where('uid', session('userInfo.id'))->where('laud_id', $id)->count();
        $this->assign([
            'vo' => $articleList,
            'is_laud' => $is_laud,
            'article_comment' => $article_comment,
            'article_comment_page' => $article_comment_page
        ]);
        return view();
    }

    /**
     * 点赞
     */
    public function myLike()
    {
        if ($this->request->isPost()) {
            $id = input('id', '', 'intval');
            $type = input('type', '', 'string');
            if (empty($id)) return json(['code' => 5, 'msg' => '参数错误！']);
            if (empty($type)) return json(['code' => 5, 'msg' => '参数错误！']);
            if (empty(session('userInfo.id'))) return json(['code' => 5, 'msg' => '登录后才能点赞哦！', 'url' => '/userInfo.html']);
            $result = 0;
            //文章点赞
            if ($type == 'atc') {
                $count = Db::name('blog_a_laud_record')->where('uid', session('userInfo.id'))->where('laud_id', $id)->count();
                if ($count >= 1) return json(['code' => 5, 'msg' => '你已点赞了哦！']);
                Db::name('blog_a_laud_record')->insert(['uid' => session('userInfo.id'), 'laud_id' => $id, 'create_at' => time()]);
                $result = Db::name('blog_article')->where('status', 1)->where('id', $id)->inc('laud_num')->update();//增加点赞数
            }
            //公告点赞
            if ($type == 'ntc') {
                $count = Db::name('blog_n_laud_record')->where('uid', session('userInfo.id'))->where('laud_id', $id)->count();
                if ($count >= 1) return json(['code' => 5, 'msg' => '你已点赞了哦！']);
                Db::name('blog_n_laud_record')->insert(['uid' => session('userInfo.id'), 'laud_id' => $id, 'create_at' => time()]);
                $result = Db::name('blog_notice')->where('status', 1)->where('id', $id)->inc('laud_num')->update();//增加点赞数
            }
            //留言点赞
            if ($type == 'msg') {
                $count = Db::name('blog_m_laud_record')->where('uid', session('userInfo.id'))->where('laud_id', $id)->count();
                if ($count >= 1) return json(['code' => 5, 'msg' => '你已点赞了哦！']);
                Db::name('blog_m_laud_record')->insert(['uid' => session('userInfo.id'), 'laud_id' => $id, 'create_at' => time()]);
                $result = Db::name('blog_messages')->where('status', 1)->where('id', $id)->inc('laud_num')->update();//增加点赞数
            }
            //文章留言点赞
            if ($type == 'atc_msg') {
                $count = Db::name('blog_am_laud_record')->where('uid', session('userInfo.id'))->where('laud_id', $id)->count();
                if ($count >= 1) return json(['code' => 5, 'msg' => '你已点赞了哦！']);
                Db::name('blog_am_laud_record')->insert(['uid' => session('userInfo.id'), 'laud_id' => $id, 'create_at' => time()]);
                $result = Db::name('blog_article_comment')->where('status', 1)->where('id', $id)->inc('laud_num')->update();//增加点赞数
            }
            return ($result > 0) ? json(['code' => 1, 'msg' => '点赞成功！']) : json(['code' => 1, 'msg' => '点赞失败！']);
        }
        return json(['code' => 5, 'msg' => '请勿GET操作！']);
    }

    /**
     * 留言评论
     */
    public function news()
    {
        if ($this->request->isPost()) {
            $act_id = input('act_id', '', 'intval');
            $type = input('type', '', 'string');
            $content = input('content', '', 'string');
            if (empty($type)) return json(['code' => 5, 'msg' => '参数错误！']);
            if (empty($content)) return json(['code' => 5, 'msg' => '参数错误！']);
            if (empty(session('userInfo.id'))) return json(['code' => 5, 'msg' => '登录后才能评论留言哦！', 'url' => '/userInfo.html']);
            //评论文章
            if ($type == 'comment') {
                if (empty($act_id)) return json(['code' => 5, 'msg' => '参数错误！']);
                if (!empty(cache('com_time_' . session('userInfo.id')))) return json(['code' => 5, 'msg' => '你评论的太快了稍后再来吧！']);
                $data['uid'] = session('userInfo.id');
                $data['act_id'] = $act_id;
                $data['content'] = $content;
                $data['create_at'] = time();
                $result = Db::name('blog_article_comment')->insert($data);//增加点赞数
                Db::name('blog_article')->where('status', 1)->where('id', $act_id)->inc('comment_num')->update();//增加点赞数
                cache('com_time_' . session('userInfo.id'), time(), 60);//60秒内不能评论
                return ($result > 0) ? json(['code' => 1, 'msg' => '评论成功！', 'url' => '/lookAtc-' . $act_id . '.html']) : json(['code' => 1, 'msg' => '评论失败！']);
            }
            //留言
            if ($type == 'message') {
                if (!empty(cache('msg_time_' . session('userInfo.id')))) return json(['code' => 5, 'msg' => '你留言的太快了稍后再来吧！']);
                $data['uid'] = session('userInfo.id');
                $data['content'] = $content;
                $data['msg_time'] = time();
                $result = Db::name('blog_messages')->insert($data);//增加点赞数
                cache('msg_time_' . session('userInfo.id'), time(), 60);//60秒内不能留言
                return ($result > 0) ? json(['code' => 1, 'msg' => '留言成功！', 'url' => '/message.html']) : json(['code' => 1, 'msg' => '留言失败！']);
            }
            return json(['code' => 1, 'msg' => '处理中...']);
        }
        return json(['code' => 5, 'msg' => '请勿GET操作！']);
    }

}