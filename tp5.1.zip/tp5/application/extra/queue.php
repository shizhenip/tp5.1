<?php

return [
    'connector' => 'Sync'
];
