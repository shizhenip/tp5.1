<?php

namespace app\api\controller;

use controller\BasicApi;

/**
 * 接口操作
 * Class Test
 * @package app\index\controller
 * @date 2017/12/01 18:12
 */
class Test extends BasicApi
{
    /**
     * 测试
     */
    public function demo()
    {
        return $this->response('SUCCESS', '请求成功！', $this->data);
    }
}