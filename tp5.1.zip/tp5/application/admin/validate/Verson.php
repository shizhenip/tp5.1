<?php

namespace app\admin\validate;

use think\Validate;

/**
 * 版本说明验证器
 * Class Verson
 * @package app\admin\controller
 * @date 2017/02/15 18:13
 */
class Verson extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'verson_number' => 'require|unique:system_verson',
    ];

    /**
     * 规则不通过返回失败信息
     */
    protected $message = [
        'verson_number.require' => '版本号不能为空！',
        'verson_number.unique' => '版本号已经存在！',
    ];
}