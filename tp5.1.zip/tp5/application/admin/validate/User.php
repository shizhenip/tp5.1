<?php

namespace app\admin\validate;

use think\Validate;

/**
 * 系统用户验证器
 * Class User
 * @package app\admin\controller
 * @date 2017/02/15 18:13
 */
class User extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'phone' => 'require|unique:system_user',
    ];

    /**
     * 规则不通过返回失败信息
     */
    protected $message = [
        'phone.require' => '手机号不能为空！',
        'phone.unique' => '手机号已经存在！',
    ];
}