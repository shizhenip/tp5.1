<?php

namespace app\admin\validate;

use think\Validate;

/**
 * 权限管理验证器
 * Class Auth
 * @package app\admin\controller
 * @date 2017/02/15 18:13
 */
class Auth extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'title' => 'require|unique:system_auth',
    ];

    /**
     * 规则不通过返回失败信息
     */
    protected $message = [
        'title.require' => '权限名称不能为空！',
        'title.unique' => '权限名称已经存在！',
    ];
}