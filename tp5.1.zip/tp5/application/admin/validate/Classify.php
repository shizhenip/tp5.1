<?php

namespace app\admin\validate;

use think\Validate;

/**
 * 无限级分类验证器
 * Class Classify
 * @package app\admin\controller
 * @date 2017/02/15 18:13
 */
class Classify extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'name' => 'require|unique:system_classify',
    ];

    /**
     * 规则不通过返回失败信息
     */
    protected $message = [
        'name.require' => '名称不能为空！',
        'name.unique' => '名称已经存在！',
    ];
}