<?php

namespace app\admin\controller;

use controller\BasicAdmin;
use service\DataService;
use service\LogService;
use think\Db;

/**
 * 系统用户管理控制器
 * Class User
 * @package app\admin\controller
 * @date 2017/02/15 18:12
 */
class User extends BasicAdmin
{
    /**
     * 指定当前数据表
     * @var string
     */
    public $table = 'SystemUser';

    /**
     * 用户列表
     */
    public function index()
    {
        // 设置页面标题
        $this->title = '用户管理';
        // 获取到所有GET参数
        $get = $this->request->get();
        // 实例Query对象
        $db = Db::name($this->table)->where('is_deleted', 0)->order('id desc');
        // 应用搜索条件
        foreach (['username', 'phone', 'mail'] as $key) {
            (isset($get[$key]) && $get[$key] !== '') && $db->whereLike($key, "%{$get[$key]}%");
        }
        // 实例化并显示
        return parent::_list($db);
    }

    /**
     * 授权权限
     */
    public function auth()
    {
        if ($this->request->isPost()) {
            LogService::write('系统管理', '授权权限');
        }
        return $this->_form($this->table, 'auth');
    }

    /**
     * 添加系统用户
     */
    public function add()
    {
        if ($this->request->isPost()) {
            LogService::write('系统管理', '添加系统用户');
        }
        return $this->_form($this->table, 'form');
    }

    /**
     * 编辑系统用户
     */
    public function edit()
    {
        if ($this->request->isPost()) {
            LogService::write('系统管理', '编辑系统用户');
        }
        return $this->_form($this->table, 'form');
    }

    /**
     * 修改用户密码
     */
    public function pass()
    {
        if (in_array($this->request->post('id'), ['10000'])) {
            $this->error('系统超级账号禁止操作！');
        }
        if ($this->request->isPost()) {
            $data = $this->request->post();
            if ($data['password'] !== $data['repassword']) {
                $this->error('两次输入的密码不一致！');
            }
            if (DataService::save($this->table, ['id' => $data['id'], 'password' => password($data['password'])], 'id')) {
                $this->success('密码修改成功，下次请使用新密码登录！', '');
            }
            LogService::write('系统管理', '修改用户密码');
            $this->error('密码修改失败，请稍候再试！');
        }
        $this->assign('verify', false);
        return $this->_form($this->table, 'pass');
    }


    /**
     * 删除系统用户
     */
    public function del()
    {
        if (in_array($this->request->post('id'), ['10000'])) {
            $this->error('系统超级账号禁止操作！');
        }
        if (DataService::update($this->table)) {
            $id = $this->request->post('id');
            $name = Db::name($this->table)->where('id', $id)->value('username');
            LogService::write('系统管理', '删除系统用户' . $name);
            $this->success("用户删除成功！", '');
        }
        $this->error("用户删除失败，请稍候再试！");
    }

    /**
     * 禁用系统用户
     */
    public function forbid()
    {
        if (in_array($this->request->post('id'), ['10000'])) {
            $this->error('系统超级账号禁止操作！');
        }
        $id = $this->request->post('id');
        $name = Db::name($this->table)->where('id', $id)->value('username');
        if (DataService::update($this->table)) {
            LogService::write('系统管理', '禁用系统用户' . $name);
            $this->success("用户禁用成功！", '');
        }
        $this->error("用户禁用失败，请稍候再试！");
    }

    /**
     * 启用系统用户
     */
    public function resume()
    {
        if (DataService::update($this->table)) {
            $id = $this->request->post('id');
            $name = Db::name($this->table)->where('id', $id)->value('username');
            LogService::write('系统管理', '启用系统用户' . $name);
            $this->success("用户启用成功！", '');
        }
        $this->error("用户启用失败，请稍候再试！");
    }

    /**
     *导入系统用户
     */
    public function upload()
    {
        if ($this->request->isPost()) {
            $filedList = ['username', 'realname', 'phone', 'mail', 'desc'];
            $file_name = input('file_name', '');
            if (sysconf('storage_type') == 'qiniu') {
                $filename = 'static/upload/' . time() . '/' . time() . '.' . pathinfo($file_name, PATHINFO_EXTENSION);
                file_put_contents($filename, file_get_contents($file_name));
            } else {
                $filename = str_replace(request()->root(true) . '/', '', $file_name);
            }
            $data = \down\Excel::upload($filename, $filedList);
            empty($data) && $this->error('导入数据有问题请检查文件！');
            exit;
            $err = 0;
//          $user_list = array();
//          $list = Db::name('system_user')->field('phone')->select();
//          foreach ($list as $k => $v) {
//               $user_list[] = $v['phone'];
//          }
//          foreach ($data as $k => $v) {
//              if (in_array($v['phone'], $user_list)) {
//                  unset($data[$k]);
//                  $err++;
//              }
//          }
            try {
                if (count($data) == 0) {
                    return json(['code' => 0, 'msg' => "暂无数据需要导入"]);
                } else {
                    foreach ($data as $k => $v) {
                        $data[$k]['password'] = password(123456);//默认密码
                        $data[$k]['create_at'] = time();
                    }
                    Db::name($this->table)->insertAll($data);
                    return json(['code' => 1, 'msg' => "成功导入" . count($data) . "条数据！", "重复数据" . $err . "条"]);
                }
            } catch (\Exception  $e) {
                $this->error($e->getMessage());
            }
        }
        return view();
    }

    /**
     * 表单数据默认处理
     * @param array $data
     */
    protected function _form_filter(&$data)
    {
        if ($this->request->isPost()) {
            if ($this->request->action() == 'add') {
                $data['password'] = password(123456);//默认密码
            }
            if (isset($data['authorize']) && is_array($data['authorize'])) {
                $data['authorize'] = join(',', $data['authorize']);
            }
            if (!isset($data['authorize'])) {
                $data['authorize'] = '';
            }
            if ($this->request->action() !== 'auth') {
                $result = $this->validate($data, 'app\admin\validate\User');
                if (true !== $result) {
                    $this->error($result);
                }
            }
        } else {
            $data['authorize'] = explode(',', isset($data['authorize']) ? $data['authorize'] : '');
            $this->assign('authorizes', Db::name('SystemAuth')->select());
        }
    }
}
