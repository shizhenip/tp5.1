<?php

namespace app\admin\controller;

use controller\BasicAdmin;
use service\DataService;
use service\LogService;
use think\Db;

/**
 * 版本管理
 * class Verson
 * @package app\admin\controller
 * @date 2017/02/10 13:59
 */
class Verson extends BasicAdmin
{
    /**
     * 指定当前数据表
     * @var string
     */
    public $table = 'SystemVerson';

    /**
     * 版本列表
     */
    public function index()
    {
        // 设置页面标题
        $this->title = '版本列表';
        // 实例Query对象
        $db = Db::name($this->table);
        // 实例化并显示
        return parent::_list($db);
    }

    /**
     * 添加版本
     */
    public function add()
    {
        if ($this->request->isPost()) {
            LogService::write('系统管理', '添加版本');
        }
        return $this->_form($this->table, 'form');
    }

    /**
     * 编辑版本
     */
    public function edit()
    {
        if ($this->request->isPost()) {
            LogService::write('系统管理', '编辑版本');
        }
        return $this->_form($this->table, 'form');
    }

    /**
     * 删除版本
     */
    public function del()
    {
        if (DataService::update($this->table)) {
            LogService::write('系统管理', '删除版本');
            $this->success("删除成功！", '');
        }
        $this->error("删除失败，请稍候再试！");
    }

    /**
     * 表单基本操作
     * @param array $data
     */
    protected function _form_filter(&$data)
    {
        if ($this->request->isPost()) {
            $result = $this->validate($data, 'app\admin\validate\Verson');
            $data['create_name'] = session('user.realname');
            $data['update_at'] = time();
            if (true !== $result) {
                $this->error($result);
            }
        }
    }
}