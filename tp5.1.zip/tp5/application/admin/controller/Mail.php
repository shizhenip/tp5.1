<?php

namespace app\admin\controller;

use controller\BasicAdmin;
use SendEmail\SendEmail;
use service\LogService;

/**
 * 发送邮件
 * Class Mail
 * @package app\admin\controller
 * @date 2017/02/15 18:05
 */
class Mail extends BasicAdmin
{
    /**
     * 默认执行表
     */
    public $table = '';

    /**
     * 发送邮件
     */
    public function index()
    {
        if ($this->request->isPost()) {
            $post = $this->request->post();
            $pattern = "/([a-z0-9]*[-_.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[.][a-z]{2,3}([.][a-z]{2})?/i";//邮箱正则
            if (!isset($post['email']) || !preg_match($pattern, $post['email'])) return json(['code' => 5, 'msg' => '收件邮箱错误！']);
            if (!isset($post['title']) || empty($post['title'])) return json(['code' => 5, 'msg' => '收件标题错误！']);
            if (!isset($post['content']) || empty($post['content'])) return json(['code' => 5, 'msg' => '收件内容错误！']);
            LogService::write('系统管理', '发送邮件');
            return SendEmail::send($post);
        }
        $this->assign('title', '发送邮件');
        return view();
    }
}