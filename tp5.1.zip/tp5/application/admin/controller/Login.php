<?php

namespace app\admin\controller;

use service\LogService;
use service\NodeService;
use think\Controller;
use think\Db;

/**
 * 系统登录控制器
 * class Login
 * @package app\admin\controller
 * @date 2017/02/10 13:59
 */
class Login extends Controller
{
    /**
     * 默认检查用户登录状态
     * @var bool
     */
    public $checkLogin = false;

    /**
     * 默认检查节点访问权限
     * @var bool
     */
    public $checkAuth = false;

    /**
     * 控制器基础方法
     */
    public function initialize()
    {
        if (session('user') && $this->request->action() !== 'out') {
            $this->redirect('@admin');
        }
    }

    /**
     * 用户登录
     * @return string
     */
    public function index()
    {
        if ($this->request->isPost()) {
            $username = $this->request->post('username', '', 'trim');
            $password = $this->request->post('password', '', 'trim');
            $code = $this->request->post('code', '', 'trim');
            (empty($code)) && $this->error('请输入验证码!');
            $verify = new \Verify();
            (empty($username) || strlen($username) < 2) && $this->error('登录账号长度不能少于2位有效字符!');
            (empty($password) || strlen($password) < 4) && $this->error('登录密码长度不能少于4位有效字符!');
            (!$verify->check($code)) && $this->error('验证码错误!');
            $user = Db::name('SystemUser')->where(self::testUser($username), $username)->where('is_deleted', 0)->where('status', 1)->find();
            empty($user) && $this->error('登录账号不存在，请重新输入!');
            ($user['password'] !== password($password)) && $this->error('登录密码与账号不匹配，请重新输入!');
            Db::name('SystemUser')->where('id', $user['id'])->inc('login_num')->update(['login_at' => time()]);
            session('user', $user);
            cookie('user', $user);
            !empty($user['authorize']) && NodeService::applyAuthNode();
            LogService::write('系统管理', '用户登录系统成功');
            $this->success('登录成功，正在进入系统...', '@admin');
        }
        return $this->fetch('index', ['title' => '用户登录']);
    }

    /**
     * 验证码
     */
    public function checkVerify()
    {
        $verify = new \Verify();
        $verify->imageH = 32;
        $verify->imageW = 100;
        $verify->length = 4;
        $verify->useZh = false;
        $verify->fontSize = 12;
        $verify->entry();
    }

    /**
     * 拖动验证码
     */
    public function getverify()
    {
        $GtSdk = new \Geetestlib(config('api.gee_id'), config('api.gee_key'));
        $web = 'web';
        $status = $GtSdk->pre_process($web);
        session('gtserver', $status);
        session('web', $web);
        echo $GtSdk->get_response_str();
    }

    /**
     * 退出登录
     */
    public function out()
    {
        LogService::write('系统管理', '用户退出系统成功');
        session('user', null);
        cookie('user', null);
        $this->success('退出登录成功！', '/login.html');
    }
    
    /**
     * 检查用户登录名格式
     * @param string $username 需要验证的用户名
     * @return string
     */
    protected static function testUser($username)
    {
        if (preg_match("/([a-z0-9]*[-_.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[.][a-z]{2,3}([.][a-z]{2})?/i", $username)) {
            return $field = 'mail';
        } elseif (isPhone($username)) {
            return $field = 'phone';
        } else {
            return $field = 'username';
        }
    }
}
