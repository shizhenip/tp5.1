<?php

namespace app\admin\controller;

use controller\BasicAdmin;
use service\DataService;
use service\LogService;
use service\NodeService;
use service\ToolsService;
use think\App;
use think\Db;
use think\facade\Env;
use think\facade\View;

/**
 * 后台入口
 * Class Index
 * @package app\admin\controller
 * @date 2017/02/15 10:41
 */
class Index extends BasicAdmin
{
    /**
     * 后台框架布局
     * @return View
     */
    public function index()
    {
        NodeService::applyAuthNode();
        $list = Db::name('SystemMenu')->where('status', 1)->order('sort asc,id asc')->cache('indexSystemMenu', 120)->select();
        $menus = $this->_filterMenu(ToolsService::arr2tree($list));
        return view('', ['title' => '系统管理', 'menus' => $menus]);
    }

    /**
     * 主机信息显示
     * @return View
     */
    public function main()
    {
        $_version = Db::query('select version() as ver');
        $version = array_pop($_version);
        return view('', ['title' => '后台首页', 'mysql_ver' => $version['ver'], 'think_ver' => App::VERSION]);
    }

    /**
     * 修改密码
     */
    public function pass()
    {
        if ($this->request->isPost()) {
            $data = $this->request->post();
            if (in_array($this->request->post('id'), ['10000'])) $this->error('系统超级账号禁止操作！');
            if (in_array($this->request->post('id'), ['10003'])) $this->error('测试账号禁止操作！');
            if ($data['password'] !== $data['repassword']) $this->error('两次输入的密码不一致，请重新输入！');
            $password = Db::name('SystemUser')->where('id', session('user.id'))->value('password');
            if (password($data['oldpassword']) !== $password) $this->error('旧密码验证失败，请重新输入！');
            if (DataService::save('SystemUser', ['id' => session('user.id'), 'password' => password($data['password'])])) {
                session('user', null);
                cookie('user', null);
                LogService::write('系统管理', '密码修改成功');
                $this->success('密码修改成功，下次请使用新密码登录！', '/login.html');
            } else {
                $this->error('密码修改失败，请稍候再试！');
            }
        }
        if (intval($this->request->request('id')) !== intval(session('user.id'))) {
            $this->error('访问异常！');
        }
        return $this->_form('SystemUser', 'pass');
    }

    /**
     * 修改资料
     */
    public function info()
    {
        if (in_array($this->request->post('id'), ['10000'])) $this->error('系统超级账号禁止操作！');
        if (intval($this->request->request('id')) !== intval(session('user.id'))) $this->error('访问异常！');
        return $this->_form('SystemUser', 'info');
    }

    /**
     * 清空文件缓存
     */
    public function clearCache()
    {
        LogService::clearCache(Env::get('runtime_path'));
        $this->success('已经成功清理缓存!', '');
    }

    /**
     * 跟换皮肤
     */
    public function skin()
    {
        return view();
    }

    /**
     * 后台主菜单权限过滤
     * @param array $menus
     * @return array
     */
    private function _filterMenu($menus)
    {
        foreach ($menus as $key => &$menu) {
            if (!empty($menu['sub'])) {
                $menu['sub'] = $this->_filterMenu($menu['sub']);
            }
            if (!empty($menu['sub'])) {
                $menu['url'] = '#';
            } elseif (stripos($menu['url'], 'http') === 0) {
                continue;
            } elseif ($menu['url'] !== '#' && auth(join('/', array_slice(explode('/', $menu['url']), 0, 3)))) {
                $menu['url'] = url($menu['url']);
            } else {
                unset($menus[$key]);
            }
        }
        return $menus;
    }
}
