<?php

namespace app\admin\controller;

use controller\BasicAdmin;
use service\DataService;
use service\LogService;
use service\ToolsService;
use think\Db;

/**
 * 无限级管理
 * Class User
 * @package app\admin\controller
 * @date 2017/02/15 18:12
 */
class Classify extends BasicAdmin
{
    /**
     * 指定当前数据表
     * @var string
     */
    public $table = 'SystemClassify';

    /**
     * 无限级列表
     */
    public function index()
    {
        // 设置页面标题
        $this->title = '无限级列表';
        // 实例Query对象
        $db = Db::name($this->table);
        // 实例化并显示
        return parent::_list($db, false);
    }

    /**
     * 添加分类
     */
    public function add()
    {
        if ($this->request->isPost()) {
            LogService::write('系统管理', '添加分类');
        }
        return $this->_form($this->table, 'form');
    }

    /**
     * 编辑分类
     */
    public function edit()
    {
        if ($this->request->isPost()) {
            LogService::write('系统管理', '编辑分类');
        }
        return $this->_form($this->table, 'form');
    }

    /**
     * 删除分类
     */
    public function del()
    {
        if (DataService::update($this->table)) {
            LogService::write('系统管理', '删除分类');
            $this->success("删除成功！", '');
        }
        $this->error("删除失败，请稍候再试！");
    }

    /**
     * 列表数据处理
     * @param array $data
     */
    protected function _data_filter(&$data)
    {
        $data = ToolsService::arr2table($data);
    }

    /**
     * 表单数据处理
     * @param array $data
     */
    protected function _form_filter(&$data)
    {
        if ($this->request->isPost()) {
            $result = $this->validate($data, 'app\admin\validate\Classify');
            if (true !== $result) $this->error($result);
        } else {
            $_menus = Db::name($this->table)->where('status', 1)->order('sort desc,id desc')->select();
            $_menus[] = ['name' => '顶级', 'id' => '0', 'pid' => '-1'];
            $menus = ToolsService::arr2table($_menus);
            $this->assign('menus', $menus);
        }
    }
}   