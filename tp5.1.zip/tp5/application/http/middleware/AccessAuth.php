<?php

namespace app\http\middleware;

use service\NodeService;
use think\Db;
use think\facade\Config;
use think\facade\View;
use think\Request;

/**
 * 访问权限管理
 * Class AccessAuth
 * @package hook
 * @date 2017/05/12 11:59
 */
class AccessAuth
{
    /**
     * 行为入口
     * @param Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, \Closure $next)
    {
        list($module, $controller, $action) = [$request->module(), $request->controller(), $request->action()];
        $access = $this->buildAuth($node = NodeService::parseNodeStr("{$module}/{$controller}/{$action}"));
        // 登录状态检查
        if (!empty($access['is_login']) && !session('user')) {
            $msg = ['code' => 0, 'msg' => '抱歉，您还没有登录获取访问权限！', 'url' => url('/login')];
            return $request->isAjax() ? json($msg) : redirect($msg['url']);
        }
        // 访问权限检查
        if (!empty($access['is_auth']) && !auth($node)) {
            return json(['code' => 0, 'msg' => '抱歉，您没有访问该模块的权限！']);
        }
        $view = View::instance(Config::get('template'), Config::get('view_replace_str'));
        $view->assign('classuri', strtolower("{$module}/{$controller}"));
        return $next($request);
    }

    /**
     * 根据节点获取对应权限配置
     * @param string $node 权限节点
     * @return array
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    private function buildAuth($node)
    {
        $info = Db::name('SystemNode')->cache(true, 30)->where(['node' => $node])->find();
        return [
            'is_menu' => intval(!empty($info['is_menu'])),
            'is_auth' => intval(!empty($info['is_auth'])),
            'is_login' => empty($info['is_auth']) ? intval(!empty($info['is_login'])) : 1,
        ];
    }

    /**
     * 函数描述 限制IP
     * @param array $ipList 不需要验证的ip列表
     * @return string
     */
    protected static function checkIp($ipList)
    {
        $IP = \think\facade\Request::instance()->ip();
        $check_ip_arr = explode('.', $IP);
        if (!in_array($IP, $ipList)) {
            foreach ($ipList as $val) {
                if (strpos($val, '*')) {
                    $arr = explode('.', $val);
                    $bl = true;
                    for ($i = 0; $i < 4; $i++) {
                        if ($arr[$i] != '*') {
                            if ($arr[$i] != $check_ip_arr[$i]) {
                                $bl = false;
                                break;
                            }
                        }
                    }
                    if ($bl) return;
                }
            }
            header('HTTP/1.1 403 Forbidden');
            die("拒绝访问");
        }
        header('HTTP/1.1 403 Forbidden');
        die("拒绝访问");
    }

}
