<?php

return [
    // 系统权限访问管理
    \app\http\middleware\AccessAuth::class
];