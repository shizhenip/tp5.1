layui.define(['layer', 'form', 'jquery'], function () {
    layer = layui.layer, form = layui.form, $ = layui.jquery;
    /*! 定义当前body对象 */
    this.$body = $('body');
    /*! 表单提交 */
    this.$body.on('submit', 'form[data-submit]', function () {
        var data = $(this).serialize();
        var url = this.action;
        $.post(url, data, function (result) {
            if (result.code !== 1) {
                layer.msg(result.msg, {icon: 5, time: 2000});
                return false;
            } else {
                layer.msg(result.msg, {icon: 1, time: 2000}, function () {
                    window.location.href = result.url;
                });
            }
        });
    });
});
