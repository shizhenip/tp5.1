
layui.define(['element', 'form', 'laypage', 'jquery', 'laytpl'], function (exports) {
    var element = layui.element, form = layui.form, laypage = layui.laypage, $ = layui.jquery, laytpl = layui.laytpl;

    // start 导航显示隐藏
    $("#mobile-nav").on('click', function () {
        $("#pop-nav").toggle();
    });
    // end 导航显示隐藏

    //点赞特效
    (function ($) {
        $.extend({
            tipsBox: function (options) {
                options = $.extend({
                    obj: null,  //jq对象，要在那个html标签上显示
                    str: "+1",  //字符串，要显示的内容;也可以传一段html，如: "<b style='font-family:Microsoft YaHei;'>+1</b>"
                    startSize: "12px",  //动画开始的文字大小
                    endSize: "30px",    //动画结束的文字大小
                    interval: 600,  //动画时间间隔
                    color: "red",    //文字颜色
                    callback: function () {
                    }    //回调函数
                }, options);
                $("body").append("<span class='num'>" + options.str + "</span>");
                var box = $(".num");
                var left = options.obj.offset().left + options.obj.width() / 2;
                var top = options.obj.offset().top - 10;
                box.css({
                    "position": "absolute",
                    "left": left + "px",
                    "top": top + "px",
                    "z-index": 9999,
                    "font-size": options.startSize,
                    "line-height": options.endSize,
                    "color": options.color
                });
                box.animate({
                    "font-size": options.endSize,
                    "opacity": "0",
                    "top": top - parseInt(options.endSize) + "px"
                }, options.interval, function () {
                    box.remove();
                    options.callback();
                });
            }
        });
    })($);

    //start 点赞的特效
    function niceIn(prop) {
        prop.find('i').addClass('niceIn');
        setTimeout(function () {
            prop.find('i').removeClass('niceIn');
        }, 1000);
    }

    //点赞
    $(function () {
        $(".like").on('click', function () {
            if (!($(this).hasClass("layblog-this"))) {
                var type = $(this).attr('data-type');
                var key = $(this).attr('data-key');
                var obj = this;
                $.post('/myLike', {type: type, id: key}, function (result) {
                    if (result.code !== 1) {
                        layer.msg(result.msg, {icon: 5, time: 1000}, function () {
                            if (result.url) window.location.href = result.url;
                        });
                    } else {
                        obj.text = '已赞';
                        $(obj).addClass('layblog-this');
                        $.tipsBox({obj: $(obj), str: '+1', callback: function () {}});
                        niceIn($(obj));
                        layer.msg(result.msg, {icon: 1, time: 2000});
                    }
                });
            }
        });
    });

    //点图片变身
    $('#LAY-msg-box').on('click', '.info-img', function () {
        $(this).addClass('layblog-this');
    });

    //评论提交
    $('#item-btn').on('click', function () {
        var content = $('.layui-form textarea[name="content"]').val();//内容
        var type = $(this).attr('data-type');//操作类型
        var act_id = $(this).attr('data-key');//主键
        if (content.replace(/\s/g, '') == '') {
            layer.msg('请先输入内容', {time: 2000});
            return $('.layui-form textarea[name="content"]').focus();
        }
        $.post('/news.html', {type: type, content: content, act_id: act_id}, function (result) {
            if (result.code !== 1) {
                layer.msg(result.msg, {icon: 5, time: 1000}, function () {
                    if (result.url) window.location.href = result.url;
                });
                return false;
            } else {
                $('.layui-form textarea[name="content"]').val('');
                layer.msg(result.msg, {icon: 1, time: 1000}, function () {
                    if (result.url) window.location.href = result.url;
                });
                // var view = $('#LAY-msg-tpl-' + type).html();
                // //模板渲染
                // laytpl(view).render(result.data, function (html) {
                //     $('#LAY-msg-box-' + type).prepend(html);
                //     $('.layui-form textarea[name="content"]').val('');
                //     layer.msg(result.msg, {icon: 1});
                // });
            }
        });
    });

    //图片遮罩
    var layerphotos = document.getElementsByClassName('layer-photos-demo');
    for (var i = 1; i <= layerphotos.length; i++) {
        layer.photos({
            photos: ".layer-photos-demo" + i + "",
            anim: 0,
        });
    }

    //点击退出登录
    $('.item .logout').click(function () {
        $.post('/logout.html', {}, function (result) {
            layer.msg(result.msg, {icon: 1, time: 2000}, function () {
                window.location.href = '/userInfo.html';
            });
        });
    });

    //输出test接口
    exports('blog', {});
});  
