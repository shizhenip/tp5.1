'use strict';
layui.use(['jquery', 'layer'], function () {
    window.jQuery = window.$ = layui.jquery;
    $(".layui-canvs").width($(window).width());
    $(".layui-canvs").height($(window).height());
});

//登录验证
$(function () {
    //刷新验证码
    $("#login-code").click(function () {
        return this.src = '/admin/login/checkVerify?tm=' + Math.random();
    });
    //清空input
    $("#username").val("");
    $("#password").val("");
    $("#code").val("");
    //异步请求
    $('#doLogin').ajaxForm({beforeSubmit: checkForm, success: complete, dataType: 'json'});
    //登录验证
    function checkForm() {
        if ($.trim($('#username').val()) == "") {
            layer.msg('请输入登录用户名', {icon: 5, time: 2000}, function (index) {
                layer.close(index);
            });
            return false;
        }
        if ($.trim($('#password').val()) == "") {
            layer.msg('请输入登录密码', {icon: 5, time: 2000}, function (index) {
                layer.close(index);
            });
            return false;
        }
    }

    //登录成功跳转
    function complete(data) {
        if (data.code == 1) {
            layer.msg(data.msg, {icon: 6, time: 2000}, function (index) {
                layer.close(index);
                window.location.href = data.data;
            });
        } else {
            $("#login-code").click();
            layer.msg(data.msg, {icon: 5, time: 2000});
            return false;
        }
    }
});