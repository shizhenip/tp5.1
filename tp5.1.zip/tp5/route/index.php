<?php

use think\facade\Route;

//前台
Route::rule('home','index/index/index');//首页
Route::rule('message','index/message/index');//留言
Route::rule('about','index/about/index');//关于
Route::rule('userInfo','index/user/index');//用户信息
Route::rule('logout','index/user/logout');//退出
Route::rule('register','index/user/register');//用户注册
Route::get('lookAtc-<id>','index/index/lookAtc', [], ['id'=>'\d+']);//查看文章
Route::get('lookNtc-<id>','index/index/lookNtc', [], ['id'=>'\d+']);//查看公告
Route::post('myLike','index/index/myLike');//点赞
Route::post('news','index/index/news');//点赞