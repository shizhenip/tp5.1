<?php

use think\facade\Route;

//后台
Route::rule('login','admin/login/index');//登录页面