<?php

// +----------------------------------------------------------------------
// | SESSION会话设置
// +----------------------------------------------------------------------

return [
    'id'                => '',
    // SESSION_ID的提交变量,解决flash上传跨域
    'var_session_id'    => 's' . substr(md5(__DIR__), -8),
    // SESSION 前缀
    'prefix'            => 'think',
    // 驱动方式 支持redis memcache memcached
    'type'              => '',
    // SESSION 保存时间
    'expire'            => 5 * 3600,
    // 是否自动开启 SESSION
    'auto_start'        => true,
];