<?php

namespace SendEmail;

use PHPMailer\PHPMailer\PHPMailer;
use think\Exception;

/**
 * 发送邮件类
 */
class SendEmail
{
    /**
     * 发送邮件
     * @param array $data 发送信息
     * @param int $port 邮箱端口
     * @param string $encoding 编码方式
     * @param string $charSet 字符集
     * @param bool $isHTML 支持html格式内容
     * @return string 手机号
     */
    public static function send($data, $port = 465, $encoding = 'base64', $charSet = 'UTF-8', $isHTML = true)
    {
        if (empty(config('third_party.EmailAuthCode'))) {
            return json(['code' => 5, 'msg' => '还没配置邮件参数！']);
        }
        $mail = new PHPMailer();//实例化
        try {
            $mail->IsSMTP();//启用SMTP
            $mail->Host = config('third_party.EmailHost');//SMTP服务器 以qq邮箱为例子
            $mail->Port = $port;//邮件发送端口
            $mail->SMTPAuth = true;//启用SMTP认证
            $mail->SMTPSecure = 'ssl';//设置安全验证方式为ssl
            $mail->CharSet = $charSet;//字符集
            $mail->Encoding = $encoding;//编码方式
            $mail->Username = config('third_party.EmailAddress');//发件邮箱
            $mail->Password = config('third_party.EmailAuthCode');//发件邮箱授权码
            $mail->Subject = $data['title'];//邮件标题
            $mail->From = config('third_party.EmailAddress');//发件邮箱
            $mail->FromName = config('third_party.EmailUsername');//发件人名称
            $mail->AddAddress($data['email'], config('third_party.EmailUsername'));//收件邮箱,发件人姓名
            $mail->IsHTML($isHTML);//支持html格式内容
            $mail->Body = $data['content'];//邮件主体内容
            $result = $mail->Send() ? 1 : 0;
            return ($result == 0) ? json(['code' => 5, 'msg' => '发送失败！']) : json(['code' => 1, 'msg' => '发送成功！']);
        } catch (Exception $e) {
            return json(['code' => 5, 'msg' => 'Mailer Error: ' . $mail->ErrorInfo]);
        }
    }
}