<?php


namespace service;

use think\Db;
use think\facade\Request;


/**
 * 操作日志服务
 * Class LogService
 * @package service
 * @date 2017/03/24 13:25
 */
class LogService
{
    /**
     * 写入操作日志
     * @param string $action 行为
     * @param string $content 内容描述
     * @param string $username 操作人
     * @param \think\db\Query|string $dbQuery 获取数据操作对象
     * @return bool
     */
    public static function write($action = '行为', $content = '内容描述', $username = '', $dbQuery = 'SystemLog')
    {
        $request = Request::instance();
        $db = is_string($dbQuery) ? Db::name($dbQuery) : $dbQuery;
        $node = strtolower(join('/', [$request->module(), $request->controller(), $request->action()]));
        $data = [
            'ip' => $request->ip(),
            'node' => $node,
            'action' => $action,
            'content' => $content,
            'username' => empty($username) ? session('user.username') . '' : $username,
            'create_at' => time()
        ];
        return $db->insert($data) !== false;
    }


    /**
     * 清空文件缓存
     * @param string $dirName 文件名
     * @return bool
     */
    public static function clearCache($dirName)
    {
        return self::delFileUnderDir($dirName) !== false;
    }

    /**
     * 清除缓存
     * @param string $dirName 文件名
     * @return bool
     */
    protected static function delFileUnderDir($dirName)
    {
        if ($handle = opendir("$dirName")) {
            while (false !== ($item = readdir($handle))) {
                if ($item != "." && $item != "..") {
                    if (is_dir("$dirName/$item")) {
                        self::delFileUnderDir("$dirName/$item");
                    } else {
                        unlink("$dirName/$item");
                    }
                }
            }
            closedir($handle);
            return true;
        }
        return false;
    }

}
