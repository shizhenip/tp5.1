<?php

namespace controller;

use service\ToolsService;
use think\facade\Cache;
use think\facade\Request;
use think\facade\Response;

/**
 * 数据接口通用控制器
 * Class BasicApi
 * @package controller
 */
class BasicApi
{
    /**
     * 访问请求对象
     * @var Request
     */
    public $request;

    /**
     * 当前访问身份
     * @var string
     */
    public $token = '';

    /**
     * 请求数据
     * @var mixed
     */
    public $data = [];

    /**
     * 是否验证token
     * @var string
     */
    public $is_token = false;

    /**
     * 基础接口SDK
     * @param object $request
     */
    public function __construct($request = null)
    {
        // CORS 跨域 Options 检测响应
        ToolsService::corsOptionsHandler();
        // 获取当前 Request 对象
        $this->request = is_null($request) ? Request::instance() : $request;
        // 安全方法请求过滤
        if (in_array(strtolower($this->request->action()), ['response', 'setcache', 'getcache', 'delcache', '_empty'])) {
            exit($this->response('ACCESS_NOT_ALLOWED', '禁止访问接口安全方法！')->send());
        }
        // 访问 Token 检测处理
        $this->token = $this->request->param('token', $this->request->header('token', ''));
        if ($this->is_token && empty($this->token)) {
            exit($this->response('ACCESS_TOKEN_FAILD', '访问TOKEN失效，请重新授权！')->send());
        }
        //get 获取数据
        if ($this->request->isGet()) $this->data = $this->request->get();
        //post 获取数据
        if ($this->request->isPost()) $this->data = $this->request->post();
        //put 获取数据
        if ($this->request->isPut()) $this->data = $this->request->put();
        //API接口调度
        $this->_empty();
    }

    /**
     * 输出返回数据
     * @param string $msg 提示消息内容
     * @param string $code 业务状态码
     * @param mixed $data 要返回的数据
     * @param string $type 返回类型 JSON XML
     * @return string
     */
    public function response($code = 'SUCCESS', $msg = '', $data = [], $type = 'json')
    {
        $result = ['code' => $code, 'msg' => $msg, 'data' => $data, 'token' => $this->token, 'dataType' => strtolower($type)];
        return Response::create($result, $type)->header(ToolsService::corsRequestHander())->code(200);
    }

    /**
     * 写入缓存
     * @param string $name 缓存标识
     * @param mixed $value 存储数据
     * @param int|null $expire 有效时间 0为永久
     * @return bool
     */
    public function setCache($name, $value, $expire = null)
    {
        return Cache::set("{$this->token}_{$name}", $value, $expire);
    }

    /**
     * 读取缓存
     * @param string $name 缓存标识
     * @param mixed $default 默认值
     * @return mixed
     */
    public function getCache($name, $default = false)
    {
        return Cache::get("{$this->token}_{$name}", $default);
    }

    /**
     * 删除缓存
     * @param string $name 缓存标识
     * @return bool
     */
    public function delCache($name)
    {
        return Cache::rm("{$this->token}_{$name}");
    }

    /**
     * API接口调度
     * @return string
     */
    public function _empty()
    {
        list($controller, $action, $method) = explode('/', $this->request->path() . '///');
        if (!empty($controller) && !empty($action)) {
            $Api = config('app_namespace') . "\\api\\{$controller}\\{$action}";
            if (method_exists($Api, $method)) {
                return $Api::$method($this);
            }
            return $this->response('API_NOT_FOUND', '访问的接口不存在！');
        }
        return $this->response('API_ERROR', '不符合标准的接口！');
    }
}
