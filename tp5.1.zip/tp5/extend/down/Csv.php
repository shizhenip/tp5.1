<?php

namespace down;

/**
 * Csv导入导出
 * Class Csv
 * @package service
 * @date 2017/03/22 15:32
 */
class Csv
{
    /**
     * CSV导入数据
     * @param string $file_name 导入文件名
     * @param array $filedList 数据字段
     * @param int $size 切割数
     * @return array|string $array
     */
    public static function uploadCsv($file_name = '', $filedList = [], $size = 5000)
    {
        $handle = fopen($file_name, 'r');
        $arr = array();
        $i = 0;
        while ($data = fgetcsv($handle)) {
            if ($i++ > 0) {//去除表头
                $arr[] = $data;
            }
        }
        $array = array();
        foreach ($arr as $k => $v) {
            foreach ($filedList as $key => $val) {
                $array[$k][$val] = iconv('GB2312//IGNORE', 'UTF-8', trim($v[$key]));
            }
        }
        return $array;
    }

    /**
     * CSV导出数据
     * @param string $file_name 导出文件名
     * @param array $titleList 文件表头
     * @param array $data 导出的数据
     */
    public static function exportCsv($file_name = '导出数据', $titleList = [], $data = [])
    {
        header("Content-type: text/html; charset=utf-8");
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename=' . $file_name . '.csv');
        header('Cache-Control: max-age=0');
        $file = fopen('php://output', "a");
        $limit = 1000;
        $calc = 0;
        $title = array();
        $tarr = array();
        foreach ($titleList as $v) {
            $title[] = iconv('UTF-8', 'GB2312//IGNORE', $v);
        }
        fputcsv($file, $title);
        foreach ($data as $v) {
            $calc++;
            if ($limit == $calc) {
                ob_flush();
                flush();
                $calc = 0;
            }
            foreach ($v as $t) {
                $tarr[] = iconv('UTF-8', 'GB2312//IGNORE', $t);
            }
            fputcsv($file, $tarr);
            unset($tarr);
        }
        unset($list);
        fclose($file);
        exit();
    }

}

?>