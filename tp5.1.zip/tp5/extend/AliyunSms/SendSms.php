<?php

namespace AliyunSms;

/**
 * 发送短信类
 */
class SendSms
{
    /**
     * 发送短信
     * @param $smsId int 短信模板ID
     * @param $phone array|int 需要发送的手机号
     * @param $options array 短信模板需要替换的变量
     * @param $remarks string 短信备注
     * @return string
     */
    public static function send($smsId, $phone, $options = [], $remarks = '')
    {
        $accessKeyId = config('third_party.aliyunSmsAccessKeyId');//阿里云accessKeyId
        $accessKeySecret = config('third_party.aliyunSmsAccessKeySecret');//阿里云accessKeySecret
        $sign = config('third_party.aliyunSmsSign');//阿里云短信签名
        if (empty($accessKeyId) || empty($accessKeySecret) || empty($sign)) {
            return json(['code' => 5, 'msg' => '还没配置短信参数！']);
        }
        $AliyunSms = new AliyunSms($accessKeyId, $accessKeySecret);
        $options['code'] = rand(10000, 99999);
        $result = $AliyunSms->sendSms($sign, $smsId, $phone, $options);//签名,模板ID,手机号码,阿里云accessKeySecret
        $result = json_decode(json_encode($result), true);
        return $result['Code'] == 'OK' ? json(['code' => 1, 'msg' => '发送成功！']) : json(['code' => 5, 'msg' => json_encode($result, JSON_UNESCAPED_UNICODE), 'wait' => 5]);
    }
}