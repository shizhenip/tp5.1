/*
 Navicat Premium Data Transfer

 Source Server         : 线下
 Source Server Type    : MySQL
 Source Server Version : 50553
 Source Host           : localhost:3306
 Source Schema         : tp5

 Target Server Type    : MySQL
 Target Server Version : 50553
 File Encoding         : 65001

 Date: 26/09/2018 20:24:08
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for blog_a_laud_record
-- ----------------------------
DROP TABLE IF EXISTS `blog_a_laud_record`;
CREATE TABLE `blog_a_laud_record`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(11) UNSIGNED DEFAULT 0 COMMENT '用户ID',
  `laud_id` int(11) UNSIGNED DEFAULT 0 COMMENT '点赞ID',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of blog_a_laud_record
-- ----------------------------
INSERT INTO `blog_a_laud_record` VALUES (10, 4, 8, 1536567971);
INSERT INTO `blog_a_laud_record` VALUES (12, 4, 2, 1536569303);
INSERT INTO `blog_a_laud_record` VALUES (13, 6, 8, 1536921049);
INSERT INTO `blog_a_laud_record` VALUES (14, 6, 2, 1536921050);
INSERT INTO `blog_a_laud_record` VALUES (15, 8, 8, 1537581764);

-- ----------------------------
-- Table structure for blog_am_laud_record
-- ----------------------------
DROP TABLE IF EXISTS `blog_am_laud_record`;
CREATE TABLE `blog_am_laud_record`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(11) UNSIGNED DEFAULT 0 COMMENT '用户ID',
  `laud_id` int(11) UNSIGNED DEFAULT 0 COMMENT '点赞ID',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of blog_am_laud_record
-- ----------------------------
INSERT INTO `blog_am_laud_record` VALUES (9, 4, 21, 1536567477);
INSERT INTO `blog_am_laud_record` VALUES (10, 4, 22, 1536567680);

-- ----------------------------
-- Table structure for blog_article
-- ----------------------------
DROP TABLE IF EXISTS `blog_article`;
CREATE TABLE `blog_article`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `author` char(64) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT '' COMMENT '作者',
  `title` varchar(125) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT '' COMMENT '文章标题',
  `cover_image` varchar(125) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT '' COMMENT '分面图',
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '文章内容',
  `read_num` int(16) UNSIGNED DEFAULT 0 COMMENT '阅读量',
  `laud_num` int(16) UNSIGNED DEFAULT 0 COMMENT '点赞量',
  `comment_num` int(16) UNSIGNED DEFAULT 0 COMMENT '评论量',
  `status` tinyint(1) UNSIGNED DEFAULT 0 COMMENT '状态(0:禁用,1:启用)',
  `issue_time` int(11) UNSIGNED DEFAULT 0 COMMENT '发布时间',
  `updata_at` int(11) UNSIGNED DEFAULT 0 COMMENT '修改时间',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of blog_article
-- ----------------------------
INSERT INTO `blog_article` VALUES (1, '小李子', '巴西漏判三次点球引争议，有失公正谁还会用VAR？', 'http://weilmanky.cn/static/upload/5b882142cdb2326e/402b319ad2db4084.jpg', '<p>近日，杭州的刘先生（化名）拨打110报警，说自己&ldquo;被妻子打&rdquo;。杭州合欢心理咨询服务中心的志愿者向刘先生提供了帮助。</p><p><img alt=\"杭州男子被家暴打110：妻子一周起码喝三次酒，喝多了就打他！\" img_height=\"356\" img_width=\"640\" inline=\"0\" src=\"http://p3.pstatp.com/large/pgc-image/1531547011828a411a4135b\" /></p><p>图文无关</p><p>妻子酒后一言不合就打人</p><p>经了解，刘先生与妻子都是二婚，结婚2年，两人生活中没有孩子。</p><p>恋爱时，刘先生就发现妻子爱喝酒，个性比较急，经常用指甲抓人。</p><p><img alt=\"杭州男子被家暴打110：妻子一周起码喝三次酒，喝多了就打他！\" img_height=\"281\" img_width=\"500\" inline=\"0\" src=\"http://p1.pstatp.com/large/pgc-image/15315470121419e383c734f\" /></p><p>&nbsp;</p><p>结婚后，他发现妻子喜欢喝酒，而且酒后易怒，脾气很爆，一言不合就用指甲抓他，打他，拿凳子砸他！妻子一周起码喝3次酒&hellip;&hellip;</p><p><img alt=\"杭州男子被家暴打110：妻子一周起码喝三次酒，喝多了就打他！\" img_height=\"240\" img_width=\"240\" inline=\"0\" src=\"http://p1.pstatp.com/large/pgc-image/1531547011820cef6885b8c\" /></p><p>&nbsp;</p><p>一言不合就打他&hellip;&hellip;</p><p>久而久之，刘先生实在吃不消了，却不知道去哪里求助，只好选择报警。</p><p>尽管经常被妻子打，</p><p>他还是很希望维持这段婚姻</p><p>也希望妻子能改改，</p><p>两个人好好生活。</p><p>律师：男性同样受到反家暴法保护</p><p>妇女和儿童一直是家庭暴力的主要受害者，与此同时，男性同样也有可能是家庭暴力受害者的组成部分。</p><p><img alt=\"杭州男子被家暴打110：妻子一周起码喝三次酒，喝多了就打他！\" img_height=\"269\" img_width=\"511\" inline=\"0\" src=\"http://p3.pstatp.com/large/pgc-image/15315470117902fdd2ac8f5\" /></p><p>&nbsp;</p><p>在我国2016年实施的《反家庭暴力法》中规定：&ldquo;家庭暴力，是指家庭成员之间以殴打、捆绑、残害、限制人身自由以及经常性谩骂、恐吓等方式实施的身体、精神等侵害行为&rdquo;。其中对受害者性别并无规定。女性对男性实施的身体、精神等侵害行为也应当认定为家庭暴力，<strong>男性家暴受害人和女性一样，应受到同样的保护。</strong></p><p>心理咨询师：男性受害者更孤独</p><p><strong>家暴中的男性受害者，往往更沉默。</strong>男性遭受家庭暴力的发生率可能占10%，甚至更多。大部分男性受害者觉得难以启齿而情愿忍气吞声拒绝求助。</p><p>因为男女在体质方面的差别等原因，男性受害者遭受家庭暴力后，相对女性受害者，在身体损伤方面会轻微一些。</p><p>同时也有一部分男性，遭受的是来自伴侣的冷暴力、精神暴力。</p><p><img alt=\"杭州男子被家暴打110：妻子一周起码喝三次酒，喝多了就打他！\" img_height=\"240\" img_width=\"240\" inline=\"0\" src=\"http://p1.pstatp.com/large/pgc-image/153154701187982e252a63f\" /></p><p>&nbsp;</p><p>但是，不论是男性还是女性受害者，遭受家暴后，所产生的心理创伤和影响是一样的。</p><p>男性在遇到家庭暴力后，处理情绪情感的方式，会比较单一直接。社会对于&ldquo;男性气质&rdquo;的要求，造成很多男性受害者无法直接表达，格外羞于寻求帮助。</p><p>女性受害者更有可能跟好朋友哭诉，寻求朋友的支持和帮助，但对于大多数男性来说，他们可以和朋友喝酒聊天，但大多数人出于&ldquo;家丑不可外扬&rdquo;等因素的考虑，永远不会和朋友谈论遭受家庭暴力的情况。</p><p><img alt=\"杭州男子被家暴打110：妻子一周起码喝三次酒，喝多了就打他！\" img_height=\"356\" img_width=\"640\" inline=\"0\" src=\"http://p1.pstatp.com/large/pgc-image/1531547011920aab7283753\" /></p><p>&nbsp;</p><p>男性受害者的求助也需鼓励</p><p>对男性家暴受害者来说，求助于他人需要很大的勇气。</p><p>即便他们迈出求助的一步，也很难顺畅地说出自己的遭遇和痛苦。他们可能会用幽默的语气来描述自己遭遇的痛苦，好像&ldquo;这并不是一件太严重的事&rdquo;。</p><p>他们在求助时，往往碍于面子，用婉转隐晦的方式询问：&ldquo;如何解决和妻子的冲突？&rdquo;&ldquo;婚姻中有矛盾怎么办？&rdquo;他们可能同时承受着暴力与内心羞耻感的双重压力，可能对自我有着强烈的自责和贬损。他们往往先试探，然后开始判断自己是否能够被理解、支持和保护，还是会直接被歧视和笑话。</p><p><img alt=\"杭州男子被家暴打110：妻子一周起码喝三次酒，喝多了就打他！\" img_height=\"336\" img_width=\"551\" inline=\"0\" src=\"http://p3.pstatp.com/large/pgc-image/15315470118575d27d09ea6\" /></p><p>&nbsp;</p><p><strong>刘先生的勇气值得鼓励和肯定</strong></p><p>合欢心理咨询服务中心主任陈淑芳说，刘先生能够报警，首先是需要肯定和鼓励的。&ldquo;适合并且安全的心理咨询和疏导将是非常重要的支持力量。根据刘先生的情绪状况及个人情况，可以通过情绪疏导、沟通方式指导、帮助个人成长等方式，缓解其情绪压力、调整认知，同时配合相关法律信息服务，帮助他走出困境。&rdquo;</p><p><strong>刘先生遭受家庭暴力后</strong></p><p><strong>选择了报警，并说出自己的遭遇</strong></p><p><strong>这样的勇气</strong></p><p><strong>女性家暴受害者也可以有！</strong></p>', 38, 0, 4, 1, 0, 1531636072, 1530960380);
INSERT INTO `blog_article` VALUES (2, '小李子', '奉公克己梵蒂冈不能', 'http://weilmanky.cn/static/upload/1fc235e7953452fe/45f41b032d15fcfc.jpg', '<p><strong>当地时间2018年7月14日，是法国的国庆日&ldquo;巴士底日&rdquo;。法国政府在香榭丽舍大街举行盛大的国庆阅兵仪式，法国总统马克龙以及一众外国领导现场观礼，然而这场极具意义的的国庆阅兵仪式上却失误频频，喜感直逼印度阅兵。</strong></p><p><img alt=\"尴尬！法国国庆阅兵状况频出，幸亏特朗普没来\" img_height=\"644\" img_width=\"1024\" inline=\"0\" src=\"http://p3.pstatp.com/large/pgc-image/1531579102126d71ec9c521\" /></p><p>&nbsp;</p><p>当地时间2018年7月14日是法国国庆日&ldquo;巴士底日&rdquo;。法国政府在香榭丽舍大街举行盛大的国庆阅兵仪式，法国总统马克龙现场观礼。这是马克龙就任法国总统以来法国第二次举行国庆阅兵仪式。恰好正在法国访问的新加坡总理李显龙也应邀出席出席阅兵仪式。此外，今年恰逢第一次世界大战结束百年，因此作为一战战胜国的法国，这次阅兵式规模也较大。</p><p>然而，在这场意义非凡的阅兵仪式上，参加阅兵的法国士兵却状况不断。</p><p>在阅兵仪式上，先是在受阅的地面方阵中用来给&ldquo;地面&rdquo;部队开路的法国警察摩托车队，表演时在毫无干扰的情况下居然出现了撞车事故。</p><p><img alt=\"尴尬！法国国庆阅兵状况频出，幸亏特朗普没来\" img_height=\"543\" img_width=\"1080\" inline=\"0\" src=\"http://p1.pstatp.com/large/pgc-image/15315791020135104c10693\" /></p><p>&nbsp;</p><p><img alt=\"尴尬！法国国庆阅兵状况频出，幸亏特朗普没来\" img_height=\"569\" img_width=\"1080\" inline=\"0\" src=\"http://p1.pstatp.com/large/pgc-image/15315791020331e022a413e\" /></p><p>&nbsp;</p><p>emmm，同样是阅兵仪式上的摩托方阵，印度阅兵了解一下。</p><p><img alt=\"尴尬！法国国庆阅兵状况频出，幸亏特朗普没来\" img_height=\"665\" img_width=\"1080\" inline=\"0\" src=\"http://p1.pstatp.com/large/pgc-image/1531579102103f4110e6f0a\" /></p><p>&nbsp;</p><p><img alt=\"尴尬！法国国庆阅兵状况频出，幸亏特朗普没来\" img_height=\"721\" img_width=\"1080\" inline=\"0\" src=\"http://p3.pstatp.com/large/pgc-image/15315791021208992b92706\" /></p><p>&nbsp;</p><p>然而，这还不是最尬的，紧接着，前来受阅的法国空军法兰西巡逻兵飞行表演队，在进行飞行表演时居然把法国国旗的颜色给弄错了，原本打算喷出法国国旗蓝白红三色彩烟的飞机，居然喷出了红蓝白红的奇妙组合。</p><p><img alt=\"尴尬！法国国庆阅兵状况频出，幸亏特朗普没来\" img_height=\"636\" img_width=\"801\" inline=\"0\" src=\"http://p1.pstatp.com/large/pgc-image/1531579102163d873b61f9c\" /></p><p>&nbsp;</p><p>眼见自己的阅兵队伍在全世界面前状况百出，现场观礼的法国总统马克龙内心是奔溃的，但还是只能尴尬又不失礼貌的拍手。</p><p><img alt=\"尴尬！法国国庆阅兵状况频出，幸亏特朗普没来\" img_height=\"576\" img_width=\"1024\" inline=\"0\" src=\"http://p9.pstatp.com/large/pgc-image/1531579102229192d508de0\" /></p><p>&nbsp;</p><p>也许他是在庆幸，最近被他频繁打脸的特朗普没有参加这场阅兵仪式，毕竟在上一次法国国庆阅兵典礼上，受邀参加的美国空军雷鸟飞行表演队可是给现场观礼的美国总统特朗普挣足了面子的。</p><p><img alt=\"尴尬！法国国庆阅兵状况频出，幸亏特朗普没来\" img_height=\"1094\" img_width=\"900\" inline=\"0\" src=\"http://p3.pstatp.com/large/pgc-image/15315791024024431b5122b\" /></p><p>&nbsp;</p><p><img alt=\"尴尬！法国国庆阅兵状况频出，幸亏特朗普没来\" img_height=\"480\" img_width=\"840\" inline=\"0\" src=\"http://p1.pstatp.com/large/pgc-image/15315791023437ba1a6510e\" /></p>', 174, 5, 1, 1, 0, 1531636062, 1531627271);
INSERT INTO `blog_article` VALUES (8, '小葡萄', '环保演习为啥向海里倒4万升爆米花？原来是石油“替身”', 'http://weilmanky.cn/static/upload/1d59907d79c7dba0/6de6b5ce03d3d27d.png', '<p>中新网8月29日电 综合报道，据瑞典海岸警卫队消息，瑞典南部举行&ldquo;Balex Delta&rdquo;海上环保演习，约4万升爆米花被放进波罗的海。明明是环保演习，为什么还要在海里倒爆米花？</p><p><img alt=\"环保演习为啥向海里倒4万升爆米花？原来是石油“替身”\" img_height=\"364\" img_width=\"550\" inline=\"0\" src=\"http://p99.pstatp.com/large/pgc-image/1535509997981530def2722\" /></p><p>资料图：爆米花 周肖 摄 图片来源：视觉中国</p><p>据报道，此次演习的目标之一是演练波罗的海沿岸国家救援部门，在发生石油泄漏和有毒化学品泄漏时的救援行动。报道称，演习任务之一就是在不到36小时内，将约4万升爆米花收集起来。</p><p>为什么要在海中放入爆米花？事实上，多年来，爆米花一直在演习中，被用作泄漏石油的&ldquo;替代品&rdquo;。爆米花能在水中很好的漂浮，对环境无害，且若救援队无法收集齐所有爆米花，它们也可以作为美味的鱼食。</p><p>据&ldquo;Balex Delta&rdquo;演习的组织者说，这个场景&ldquo;将模拟一次巨型石油泄漏事件，瑞典将无法单独处理。&rdquo;&ldquo;石油漂浮不会受国家边界限制，国际合作是至关重要的&rdquo;，瑞典海岸警卫队的项目负责人说。</p><p>从1989年开始，&ldquo;Balex Delta&rdquo;演习每年都在地区合作框架内举行，明年将在丹麦举行。</p>', 313, 13, 7, 1, 0, 1535534071, 1535534071);

-- ----------------------------
-- Table structure for blog_article_comment
-- ----------------------------
DROP TABLE IF EXISTS `blog_article_comment`;
CREATE TABLE `blog_article_comment`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(11) UNSIGNED DEFAULT 0 COMMENT '用户ID',
  `laud_num` int(10) UNSIGNED DEFAULT 0 COMMENT '点赞数',
  `act_id` int(11) UNSIGNED DEFAULT 0 COMMENT '文章ID',
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '评论内容',
  `status` tinyint(1) UNSIGNED DEFAULT 1 COMMENT '状态(0:禁用,1:启用)',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '评论时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 33 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of blog_article_comment
-- ----------------------------
INSERT INTO `blog_article_comment` VALUES (1, 1, 0, 2, '第八代布斯克茨', 1, 1535626942);
INSERT INTO `blog_article_comment` VALUES (2, 1, 0, 2, '发顺丰哪个服是啊实打实大师多方便给对方', 1, 1535626999);
INSERT INTO `blog_article_comment` VALUES (3, 1, 0, 2, '撑不住错别字课程表', 1, 1535627060);
INSERT INTO `blog_article_comment` VALUES (4, 1, 0, 2, '萨达', 1, 1535627211);
INSERT INTO `blog_article_comment` VALUES (5, 1, 0, 2, 'sdafaf', 1, 1535711136);
INSERT INTO `blog_article_comment` VALUES (6, 1, 0, 2, '64161', 1, 1535711399);
INSERT INTO `blog_article_comment` VALUES (7, 1, 0, 2, '555', 1, 1535711533);
INSERT INTO `blog_article_comment` VALUES (8, 1, 1, 8, '55', 1, 1535711635);
INSERT INTO `blog_article_comment` VALUES (9, 1, 1, 8, 'dsgfsd ', 1, 1535711789);
INSERT INTO `blog_article_comment` VALUES (10, 4, 0, 8, 'vvv', 1, 1535711894);
INSERT INTO `blog_article_comment` VALUES (11, 4, 0, 8, 'hhg', 1, 1535711961);
INSERT INTO `blog_article_comment` VALUES (12, 4, 0, 8, 'sd', 1, 1535711985);
INSERT INTO `blog_article_comment` VALUES (13, 4, 0, 8, 'fff', 1, 1535712493);
INSERT INTO `blog_article_comment` VALUES (14, 4, 0, 2, 'ds', 1, 1535712633);
INSERT INTO `blog_article_comment` VALUES (15, 4, 0, 2, '33', 1, 1535713503);
INSERT INTO `blog_article_comment` VALUES (16, 4, 0, 2, '555', 1, 1535713604);
INSERT INTO `blog_article_comment` VALUES (17, 4, 0, 8, '555', 1, 1536315643);
INSERT INTO `blog_article_comment` VALUES (18, 4, 0, 8, 'fdsfg', 1, 1536315656);
INSERT INTO `blog_article_comment` VALUES (19, 4, 0, 8, 'fsef', 1, 1536315884);
INSERT INTO `blog_article_comment` VALUES (20, 4, 0, 8, 'dsf', 1, 1536315991);
INSERT INTO `blog_article_comment` VALUES (21, 4, 2, 8, '感受到房间里的', 1, 1536317927);
INSERT INTO `blog_article_comment` VALUES (22, 3, 3, 8, '你西欧安排部分噶女\n', 1, 1536491076);
INSERT INTO `blog_article_comment` VALUES (23, 3, 0, 8, '编号是否比较大三U盾萨福克哈撒飞洒李开复都不会打副本几乎都是分机号是发计划书放得开了较好的司法部就考虑到书房里北京市大房间号达萨法吧话费卡三等奖和健康撒谎的卡卡绝不是个萨达揭不开锅萨杜客户撒大客户撒反对客户撒地方京东方妇女节撒谎卡刷卡是哦啊都IQ我ink撒旦教hi群殴我让拉斯科巴萨陈丽娜千万里的奖品我擦送苍井空索尼大法拉请大家快打死你的放开了和千万人聘请我的你美女福利群文件夹放弃我放假了千万无法让我去二非完全方法问发是出去玩到访飞个人挺好过 大萨达问题额外给而定个', 1, 1536572280);
INSERT INTO `blog_article_comment` VALUES (24, 6, 0, 8, '分解符', 1, 1536921075);
INSERT INTO `blog_article_comment` VALUES (25, 6, 0, 8, '佛挡杀佛', 1, 1536921081);
INSERT INTO `blog_article_comment` VALUES (26, 6, 0, 1, '各地的丰富的非', 1, 1536921094);
INSERT INTO `blog_article_comment` VALUES (27, 6, 0, 1, '关闭第三个', 1, 1536921101);
INSERT INTO `blog_article_comment` VALUES (28, 6, 0, 1, '过不过关', 1, 1536921108);
INSERT INTO `blog_article_comment` VALUES (29, 7, 0, 8, 'asfasfsafsdf', 1, 1537429318);
INSERT INTO `blog_article_comment` VALUES (30, 8, 0, 8, '1111111111111111111111111111111111', 1, 1537581773);
INSERT INTO `blog_article_comment` VALUES (31, 8, 0, 8, '百度测试', 1, 1537581861);
INSERT INTO `blog_article_comment` VALUES (32, 12, 0, 1, '啪了个啪啪', 1, 1537821520);

-- ----------------------------
-- Table structure for blog_m_laud_record
-- ----------------------------
DROP TABLE IF EXISTS `blog_m_laud_record`;
CREATE TABLE `blog_m_laud_record`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(11) UNSIGNED DEFAULT 0 COMMENT '用户ID',
  `laud_id` int(11) UNSIGNED DEFAULT 0 COMMENT '点赞ID',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of blog_m_laud_record
-- ----------------------------
INSERT INTO `blog_m_laud_record` VALUES (9, 4, 12, 1536567790);

-- ----------------------------
-- Table structure for blog_messages
-- ----------------------------
DROP TABLE IF EXISTS `blog_messages`;
CREATE TABLE `blog_messages`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) UNSIGNED DEFAULT 0 COMMENT '用户ID',
  `laud_num` int(10) UNSIGNED DEFAULT 0 COMMENT '点赞数',
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '留言内容',
  `is_reply` tinyint(1) UNSIGNED DEFAULT 0 COMMENT '0:未回复 1:已回复',
  `status` tinyint(1) UNSIGNED DEFAULT 1 COMMENT '状态(0:禁用,1:启用)',
  `msg_time` int(11) UNSIGNED DEFAULT 0 COMMENT '留言时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 35 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of blog_messages
-- ----------------------------
INSERT INTO `blog_messages` VALUES (1, 1, 0, '疯疯傻傻回复水电费反倒是多个偶规范的高考大公开电饭锅放到搜个大概多少', 0, 1, 1530773164);
INSERT INTO `blog_messages` VALUES (2, 1, 0, '是打开失败开发隧道', 0, 1, 1535709604);
INSERT INTO `blog_messages` VALUES (3, 1, 0, '你说你傻逼你把', 0, 1, 1535709636);
INSERT INTO `blog_messages` VALUES (4, 1, 0, '分厉害了啊', 0, 1, 1535709683);
INSERT INTO `blog_messages` VALUES (5, 1, 0, '分分钱', 0, 1, 1535709686);
INSERT INTO `blog_messages` VALUES (6, 1, 0, '放弃我去玩', 0, 1, 1535709688);
INSERT INTO `blog_messages` VALUES (7, 1, 0, '555', 0, 1, 1535711588);
INSERT INTO `blog_messages` VALUES (8, 1, 0, 'afs', 0, 1, 1535711803);
INSERT INTO `blog_messages` VALUES (9, 1, 2, 'ggg', 0, 1, 1535711971);
INSERT INTO `blog_messages` VALUES (10, 1, 3, '666', 0, 1, 1535712558);
INSERT INTO `blog_messages` VALUES (11, 1, 5, '99', 0, 1, 1536298807);
INSERT INTO `blog_messages` VALUES (12, 4, 2, '功能的时刻发挥\n', 0, 1, 1536317952);
INSERT INTO `blog_messages` VALUES (13, 6, 0, '佛挡杀佛', 0, 1, 1536921027);
INSERT INTO `blog_messages` VALUES (14, 6, 0, '哈哈哈哈', 0, 1, 1536921037);
INSERT INTO `blog_messages` VALUES (15, 6, 0, '你觉得是客服纳斯达克', 0, 1, 1536921041);
INSERT INTO `blog_messages` VALUES (16, 6, 0, '发你你方法见附件\n', 0, 1, 1536921267);
INSERT INTO `blog_messages` VALUES (17, 6, 0, '范德萨范德萨发', 0, 1, 1536921271);
INSERT INTO `blog_messages` VALUES (18, 6, 0, '讲话稿就如同是发达股份过不过分', 0, 1, 1536921276);
INSERT INTO `blog_messages` VALUES (19, 6, 0, '功能梵蒂冈的身份VB烦得很', 0, 1, 1536921281);
INSERT INTO `blog_messages` VALUES (20, 6, 0, '共多少佛挡杀佛备份的', 0, 1, 1536921286);
INSERT INTO `blog_messages` VALUES (21, 6, 0, '发的噶动感反而是的房地产法方面军', 0, 1, 1536921297);
INSERT INTO `blog_messages` VALUES (22, 6, 0, '不梵蒂冈', 0, 1, 1536921301);
INSERT INTO `blog_messages` VALUES (23, 6, 0, '2244122112', 0, 1, 1536921307);
INSERT INTO `blog_messages` VALUES (24, 6, 0, '1354153121', 0, 1, 1536921311);
INSERT INTO `blog_messages` VALUES (25, 6, 0, '额粉色发半年付广告费', 0, 1, 1536921316);
INSERT INTO `blog_messages` VALUES (26, 6, 0, '他如果很大', 0, 1, 1536921320);
INSERT INTO `blog_messages` VALUES (27, 6, 0, '434', 0, 1, 1536921525);
INSERT INTO `blog_messages` VALUES (28, 6, 0, '不符合', 0, 1, 1536921609);
INSERT INTO `blog_messages` VALUES (29, 6, 0, '5556', 0, 1, 1536922175);
INSERT INTO `blog_messages` VALUES (30, 6, 0, '5555', 0, 1, 1536922236);
INSERT INTO `blog_messages` VALUES (31, 7, 0, 'aaaaaaaaaaaaa', 0, 1, 1537429296);
INSERT INTO `blog_messages` VALUES (32, 8, 0, '111111111111111111111111111111111111111', 0, 1, 1537581752);
INSERT INTO `blog_messages` VALUES (33, 11, 0, 'ewrwrwer', 0, 1, 1537805207);
INSERT INTO `blog_messages` VALUES (34, 12, 0, '啪了个啪啪', 0, 1, 1537821491);

-- ----------------------------
-- Table structure for blog_n_laud_record
-- ----------------------------
DROP TABLE IF EXISTS `blog_n_laud_record`;
CREATE TABLE `blog_n_laud_record`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(11) UNSIGNED DEFAULT 0 COMMENT '用户ID',
  `laud_id` int(11) UNSIGNED DEFAULT 0 COMMENT '点赞ID',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of blog_n_laud_record
-- ----------------------------
INSERT INTO `blog_n_laud_record` VALUES (12, 4, 57, 1536569356);
INSERT INTO `blog_n_laud_record` VALUES (13, 6, 57, 1536921124);

-- ----------------------------
-- Table structure for blog_notice
-- ----------------------------
DROP TABLE IF EXISTS `blog_notice`;
CREATE TABLE `blog_notice`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(125) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '标题',
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '公告内容',
  `read_num` int(11) UNSIGNED DEFAULT 0 COMMENT '阅读量',
  `laud_num` int(11) UNSIGNED DEFAULT 0 COMMENT '点赞量',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '发布时间',
  `updata_at` int(11) UNSIGNED DEFAULT 0 COMMENT '更新时间',
  `status` tinyint(1) UNSIGNED DEFAULT 0 COMMENT '0:禁用 1:启用',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 58 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of blog_notice
-- ----------------------------
INSERT INTO `blog_notice` VALUES (57, '渴望脱单的中国女人，就是不结婚', '翻滚吧开始的减肥不开始的部分开始的奶粉卡萨办法见不到斯卡迪撒胡椒粉不得不出门后十八酒坊', 89, 6, 1528713074, 1530773164, 1);

-- ----------------------------
-- Table structure for blog_user
-- ----------------------------
DROP TABLE IF EXISTS `blog_user`;
CREATE TABLE `blog_user`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(125) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '登录账号',
  `password` char(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '登录密码',
  `mail` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '联系邮箱',
  `phone` bigint(12) UNSIGNED DEFAULT 0 COMMENT '联系手机号',
  `head_img` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '头像',
  `status` tinyint(1) UNSIGNED DEFAULT 1 COMMENT '状态(0:禁用,1:启用)',
  `is_deleted` tinyint(1) UNSIGNED DEFAULT 0 COMMENT '删除状态(1:删除,0:未删)',
  `login_num` bigint(20) UNSIGNED DEFAULT 0 COMMENT '登录次数',
  `login_at` int(11) UNSIGNED DEFAULT 0 COMMENT '最后登录时间',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `index_phone`(`phone`) USING BTREE,
  INDEX `is_deleted`(`is_deleted`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统用户表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of blog_user
-- ----------------------------
INSERT INTO `blog_user` VALUES (1, '小明在这李', 'bf1e814260c3d7a4c4ecf0902cc45fb8', '', 13465684596, 'http://weilmanky.cn/static/index/images/head/1.jpg', 0, 1, 0, 0, 1530943972);
INSERT INTO `blog_user` VALUES (2, '萨芬撒发', 'bf1e814260c3d7a4c4ecf0902cc45fb8', '', 16956565556, 'http://weilmanky.cn/static/index/images/head/2.jpg', 0, 1, 0, 0, 1530946466);
INSERT INTO `blog_user` VALUES (3, '你爸爸', 'bf1e814260c3d7a4c4ecf0902cc45fb8', '', 13200000000, 'http://weilmanky.cn/static/index/images/head/3.jpg', 0, 1, 2, 1536569866, 1536314966);
INSERT INTO `blog_user` VALUES (4, '666', 'c136a51d2654016a389cf31fa94c6efa', '', 13200000001, 'http://weilmanky.cn/static/index/images/head/4.jpg', 0, 1, 4, 1536564940, 1536314966);
INSERT INTO `blog_user` VALUES (5, '555', 'bf1e814260c3d7a4c4ecf0902cc45fb8', '', 13100000000, 'http://weilmanky.cn/static/index/images/head/7.jpg', 0, 1, 1, 1536490952, 1536490938);
INSERT INTO `blog_user` VALUES (6, '你芭比的芭比', 'bf1e814260c3d7a4c4ecf0902cc45fb8', '', 13300000000, 'http://weilmanky.cn/static/index/images/head/14.jpg', 1, 0, 1, 1536921008, 1536920982);
INSERT INTO `blog_user` VALUES (7, 'aaa', '27a78c8af36e720d6d4dddf35f6d4ea7', '', 15111111111, 'http://weilmanky.cn/static/index/images/head/19.jpg', 1, 0, 1, 1537429284, 1537429274);
INSERT INTO `blog_user` VALUES (8, '123456', 'bf1e814260c3d7a4c4ecf0902cc45fb8', '', 13111111111, 'http://weilmanky.cn/static/index/images/head/18.jpg', 1, 0, 1, 1537581737, 1537581727);
INSERT INTO `blog_user` VALUES (9, '111', 'bf1e814260c3d7a4c4ecf0902cc45fb8', '', 15832779856, 'http://weilmanky.cn/static/index/images/head/1.jpg', 1, 0, 1, 1537743560, 1537743543);
INSERT INTO `blog_user` VALUES (10, 'dfwd', '3c45b987cc0c266eb1aa27024e29ce1a', '', 18232133123, 'http://weilmanky.cn/static/index/images/head/11.jpg', 1, 0, 0, 0, 1537805166);
INSERT INTO `blog_user` VALUES (11, 'dfwd', '3c45b987cc0c266eb1aa27024e29ce1a', '', 18123213138, 'http://weilmanky.cn/static/index/images/head/12.jpg', 1, 0, 1, 1537805192, 1537805186);
INSERT INTO `blog_user` VALUES (12, '啪了个啪啪', 'bf1e814260c3d7a4c4ecf0902cc45fb8', '', 17757863353, 'http://weilmanky.cn/static/index/images/head/18.jpg', 1, 0, 2, 1537821474, 1537821450);

-- ----------------------------
-- Table structure for system_auth
-- ----------------------------
DROP TABLE IF EXISTS `system_auth`;
CREATE TABLE `system_auth`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT 0 COMMENT '上级id',
  `title` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '权限名称',
  `status` tinyint(1) UNSIGNED DEFAULT 1 COMMENT '状态(1:禁用,2:启用)',
  `sort` smallint(6) UNSIGNED DEFAULT 0 COMMENT '排序权重',
  `desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '备注说明',
  `create_by` bigint(11) UNSIGNED DEFAULT 0 COMMENT '创建人',
  `create_at` int(11) DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `index_system_auth_title`(`title`) USING BTREE,
  INDEX `index_system_auth_status`(`status`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统权限表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of system_auth
-- ----------------------------
INSERT INTO `system_auth` VALUES (1, 0, '管理员', 1, 1445, '系统管理人员', 0, 1498295381);
INSERT INTO `system_auth` VALUES (2, 0, '测试权限', 1, 333, '测试权限', 0, 0);

-- ----------------------------
-- Table structure for system_auth_node
-- ----------------------------
DROP TABLE IF EXISTS `system_auth_node`;
CREATE TABLE `system_auth_node`  (
  `auth` bigint(20) UNSIGNED DEFAULT NULL COMMENT '角色ID',
  `node` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '节点路径',
  INDEX `index_system_auth_auth`(`auth`) USING BTREE,
  INDEX `index_system_auth_node`(`node`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色与节点关系表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of system_auth_node
-- ----------------------------
INSERT INTO `system_auth_node` VALUES (4, 'admin');
INSERT INTO `system_auth_node` VALUES (4, 'admin/auth');
INSERT INTO `system_auth_node` VALUES (4, 'admin/auth/index');
INSERT INTO `system_auth_node` VALUES (4, 'admin/auth/apply');
INSERT INTO `system_auth_node` VALUES (4, 'admin/auth/add');
INSERT INTO `system_auth_node` VALUES (4, 'admin/auth/edit');
INSERT INTO `system_auth_node` VALUES (4, 'admin/auth/forbid');
INSERT INTO `system_auth_node` VALUES (4, 'admin/auth/resume');
INSERT INTO `system_auth_node` VALUES (4, 'admin/auth/del');
INSERT INTO `system_auth_node` VALUES (4, 'admin/config');
INSERT INTO `system_auth_node` VALUES (4, 'admin/config/index');
INSERT INTO `system_auth_node` VALUES (4, 'admin/config/file');
INSERT INTO `system_auth_node` VALUES (4, 'admin/department');
INSERT INTO `system_auth_node` VALUES (4, 'admin/department/index');
INSERT INTO `system_auth_node` VALUES (4, 'admin/department/add');
INSERT INTO `system_auth_node` VALUES (4, 'admin/department/edit');
INSERT INTO `system_auth_node` VALUES (4, 'admin/department/del');
INSERT INTO `system_auth_node` VALUES (4, 'admin/log');
INSERT INTO `system_auth_node` VALUES (4, 'admin/log/index');
INSERT INTO `system_auth_node` VALUES (4, 'admin/log/del');
INSERT INTO `system_auth_node` VALUES (4, 'admin/menu');
INSERT INTO `system_auth_node` VALUES (4, 'admin/menu/index');
INSERT INTO `system_auth_node` VALUES (4, 'admin/menu/add');
INSERT INTO `system_auth_node` VALUES (4, 'admin/menu/del');
INSERT INTO `system_auth_node` VALUES (4, 'admin/menu/forbid');
INSERT INTO `system_auth_node` VALUES (4, 'admin/menu/resume');
INSERT INTO `system_auth_node` VALUES (4, 'admin/node');
INSERT INTO `system_auth_node` VALUES (4, 'admin/node/index');
INSERT INTO `system_auth_node` VALUES (4, 'admin/node/save');
INSERT INTO `system_auth_node` VALUES (4, 'admin/sms');
INSERT INTO `system_auth_node` VALUES (4, 'admin/sms/index');
INSERT INTO `system_auth_node` VALUES (4, 'admin/sms/seesms');
INSERT INTO `system_auth_node` VALUES (4, 'admin/sms/templete');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user/index');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user/auth');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user/auth_form');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user/add');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user/edit');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user/pass');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user/del');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user/forbid');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user/resume');
INSERT INTO `system_auth_node` VALUES (4, 'admin/user/upload_user');
INSERT INTO `system_auth_node` VALUES (4, 'wechat');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/config');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/config/index');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/config/pay');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/fans');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/fans/index');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/fans/back');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/fans/backadd');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/fans/backdel');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/fans/tagadd');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/fans/tagdel');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/fans/sync');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/keys');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/keys/index');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/keys/add');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/keys/edit');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/keys/del');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/keys/forbid');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/keys/resume');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/keys/subscribe');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/keys/defaults');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/menu');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/menu/index');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/menu/edit');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/menu/cancel');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/news');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/news/index');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/news/select');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/news/add');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/news/edit');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/news/del');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/news/push');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/tags');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/tags/index');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/tags/add');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/tags/edit');
INSERT INTO `system_auth_node` VALUES (4, 'wechat/tags/sync');
INSERT INTO `system_auth_node` VALUES (11, 'admin');
INSERT INTO `system_auth_node` VALUES (11, 'admin/sms');
INSERT INTO `system_auth_node` VALUES (11, 'admin/sms/index');
INSERT INTO `system_auth_node` VALUES (11, 'admin/sms/seesms');
INSERT INTO `system_auth_node` VALUES (20, 'admin');
INSERT INTO `system_auth_node` VALUES (20, 'admin/sms');
INSERT INTO `system_auth_node` VALUES (20, 'admin/sms/index');
INSERT INTO `system_auth_node` VALUES (20, 'admin/sms/seesms');
INSERT INTO `system_auth_node` VALUES (52, 'admin');
INSERT INTO `system_auth_node` VALUES (52, 'admin/sms');
INSERT INTO `system_auth_node` VALUES (52, 'admin/sms/index');
INSERT INTO `system_auth_node` VALUES (52, 'admin/sms/seesms');
INSERT INTO `system_auth_node` VALUES (52, 'admin/sms/templete');
INSERT INTO `system_auth_node` VALUES (52, 'wechat');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/fans');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/fans/index');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/fans/back');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/fans/backadd');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/fans/backdel');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/fans/tagadd');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/fans/tagdel');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/fans/sync');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/keys');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/keys/index');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/keys/add');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/keys/edit');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/keys/del');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/keys/forbid');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/keys/resume');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/keys/subscribe');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/keys/defaults');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/menu');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/menu/index');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/menu/edit');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/menu/cancel');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/news');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/news/index');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/news/select');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/news/add');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/news/edit');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/news/del');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/news/push');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/tags');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/tags/index');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/tags/add');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/tags/edit');
INSERT INTO `system_auth_node` VALUES (52, 'wechat/tags/sync');
INSERT INTO `system_auth_node` VALUES (43, 'admin');
INSERT INTO `system_auth_node` VALUES (43, 'admin/sms');
INSERT INTO `system_auth_node` VALUES (43, 'admin/sms/index');
INSERT INTO `system_auth_node` VALUES (43, 'admin/sms/seesms');
INSERT INTO `system_auth_node` VALUES (23, 'admin');
INSERT INTO `system_auth_node` VALUES (23, 'admin/user');
INSERT INTO `system_auth_node` VALUES (23, 'admin/user/index');
INSERT INTO `system_auth_node` VALUES (23, 'admin/user/auth');
INSERT INTO `system_auth_node` VALUES (23, 'admin/user/auth_form');
INSERT INTO `system_auth_node` VALUES (23, 'admin/user/add');
INSERT INTO `system_auth_node` VALUES (23, 'admin/user/edit');
INSERT INTO `system_auth_node` VALUES (23, 'admin/user/del');
INSERT INTO `system_auth_node` VALUES (23, 'admin/user/is_counselor');
INSERT INTO `system_auth_node` VALUES (59, 'admin');
INSERT INTO `system_auth_node` VALUES (59, 'admin/auth');
INSERT INTO `system_auth_node` VALUES (59, 'admin/auth/index');
INSERT INTO `system_auth_node` VALUES (59, 'admin/auth/apply');
INSERT INTO `system_auth_node` VALUES (59, 'admin/auth/add');
INSERT INTO `system_auth_node` VALUES (59, 'admin/auth/edit');
INSERT INTO `system_auth_node` VALUES (59, 'admin/auth/forbid');
INSERT INTO `system_auth_node` VALUES (59, 'admin/auth/resume');
INSERT INTO `system_auth_node` VALUES (59, 'admin/auth/del');
INSERT INTO `system_auth_node` VALUES (59, 'admin/config');
INSERT INTO `system_auth_node` VALUES (59, 'admin/config/index');
INSERT INTO `system_auth_node` VALUES (59, 'admin/config/file');
INSERT INTO `system_auth_node` VALUES (59, 'admin/data');
INSERT INTO `system_auth_node` VALUES (59, 'admin/data/index');
INSERT INTO `system_auth_node` VALUES (59, 'admin/data/export');
INSERT INTO `system_auth_node` VALUES (59, 'admin/data/optimize');
INSERT INTO `system_auth_node` VALUES (59, 'admin/data/repair');
INSERT INTO `system_auth_node` VALUES (59, 'admin/data/import');
INSERT INTO `system_auth_node` VALUES (59, 'admin/data/del');
INSERT INTO `system_auth_node` VALUES (59, 'admin/data/revert');
INSERT INTO `system_auth_node` VALUES (59, 'admin/department');
INSERT INTO `system_auth_node` VALUES (59, 'admin/department/index');
INSERT INTO `system_auth_node` VALUES (59, 'admin/department/add');
INSERT INTO `system_auth_node` VALUES (59, 'admin/department/edit');
INSERT INTO `system_auth_node` VALUES (59, 'admin/department/del');
INSERT INTO `system_auth_node` VALUES (59, 'admin/log');
INSERT INTO `system_auth_node` VALUES (59, 'admin/log/index');
INSERT INTO `system_auth_node` VALUES (59, 'admin/log/del');
INSERT INTO `system_auth_node` VALUES (59, 'admin/menu');
INSERT INTO `system_auth_node` VALUES (59, 'admin/menu/index');
INSERT INTO `system_auth_node` VALUES (59, 'admin/menu/add');
INSERT INTO `system_auth_node` VALUES (59, 'admin/menu/del');
INSERT INTO `system_auth_node` VALUES (59, 'admin/menu/forbid');
INSERT INTO `system_auth_node` VALUES (59, 'admin/menu/resume');
INSERT INTO `system_auth_node` VALUES (59, 'admin/node');
INSERT INTO `system_auth_node` VALUES (59, 'admin/node/index');
INSERT INTO `system_auth_node` VALUES (59, 'admin/node/save');
INSERT INTO `system_auth_node` VALUES (59, 'admin/sms');
INSERT INTO `system_auth_node` VALUES (59, 'admin/sms/index');
INSERT INTO `system_auth_node` VALUES (59, 'admin/sms/seesms');
INSERT INTO `system_auth_node` VALUES (59, 'admin/sms/templete');
INSERT INTO `system_auth_node` VALUES (59, 'admin/sms/sendsms');
INSERT INTO `system_auth_node` VALUES (59, 'admin/sms/add');
INSERT INTO `system_auth_node` VALUES (59, 'admin/sms/edit');
INSERT INTO `system_auth_node` VALUES (59, 'admin/sms/forbid');
INSERT INTO `system_auth_node` VALUES (59, 'admin/sms/resume');
INSERT INTO `system_auth_node` VALUES (59, 'admin/sms/del');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/index');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/auth');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/auth_form');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/add');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/edit');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/pass');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/del');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/forbid');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/resume');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/upload_user');
INSERT INTO `system_auth_node` VALUES (59, 'admin/user/is_counselor');
INSERT INTO `system_auth_node` VALUES (59, 'admin/verson');
INSERT INTO `system_auth_node` VALUES (59, 'admin/verson/index');
INSERT INTO `system_auth_node` VALUES (59, 'admin/verson/add');
INSERT INTO `system_auth_node` VALUES (59, 'admin/verson/edit');
INSERT INTO `system_auth_node` VALUES (59, 'admin/verson/del');
INSERT INTO `system_auth_node` VALUES (59, 'wechat');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/config');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/config/index');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/config/pay');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/fans');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/fans/index');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/fans/back');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/fans/backadd');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/fans/backdel');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/fans/tagadd');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/fans/tagdel');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/fans/sync');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/keys');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/keys/index');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/keys/add');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/keys/edit');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/keys/del');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/keys/forbid');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/keys/resume');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/keys/subscribe');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/keys/defaults');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/menu');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/menu/index');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/menu/edit');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/menu/cancel');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/news');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/news/index');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/news/select');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/news/add');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/news/edit');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/news/del');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/news/push');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/tags');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/tags/index');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/tags/add');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/tags/edit');
INSERT INTO `system_auth_node` VALUES (59, 'wechat/tags/sync');
INSERT INTO `system_auth_node` VALUES (1, 'admin');
INSERT INTO `system_auth_node` VALUES (1, 'admin/auth');
INSERT INTO `system_auth_node` VALUES (1, 'admin/auth/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/auth/apply');
INSERT INTO `system_auth_node` VALUES (1, 'admin/auth/add');
INSERT INTO `system_auth_node` VALUES (1, 'admin/auth/edit');
INSERT INTO `system_auth_node` VALUES (1, 'admin/auth/forbid');
INSERT INTO `system_auth_node` VALUES (1, 'admin/auth/resume');
INSERT INTO `system_auth_node` VALUES (1, 'admin/auth/del');
INSERT INTO `system_auth_node` VALUES (1, 'admin/classify');
INSERT INTO `system_auth_node` VALUES (1, 'admin/classify/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/classify/add');
INSERT INTO `system_auth_node` VALUES (1, 'admin/classify/edit');
INSERT INTO `system_auth_node` VALUES (1, 'admin/classify/del');
INSERT INTO `system_auth_node` VALUES (1, 'admin/config');
INSERT INTO `system_auth_node` VALUES (1, 'admin/config/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/config/file');
INSERT INTO `system_auth_node` VALUES (1, 'admin/data');
INSERT INTO `system_auth_node` VALUES (1, 'admin/data/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/data/export');
INSERT INTO `system_auth_node` VALUES (1, 'admin/data/optimize');
INSERT INTO `system_auth_node` VALUES (1, 'admin/data/repair');
INSERT INTO `system_auth_node` VALUES (1, 'admin/data/import');
INSERT INTO `system_auth_node` VALUES (1, 'admin/data/del');
INSERT INTO `system_auth_node` VALUES (1, 'admin/data/revert');
INSERT INTO `system_auth_node` VALUES (1, 'admin/log');
INSERT INTO `system_auth_node` VALUES (1, 'admin/log/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/log/del');
INSERT INTO `system_auth_node` VALUES (1, 'admin/log/export');
INSERT INTO `system_auth_node` VALUES (1, 'admin/mail');
INSERT INTO `system_auth_node` VALUES (1, 'admin/mail/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/menu');
INSERT INTO `system_auth_node` VALUES (1, 'admin/menu/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/menu/add');
INSERT INTO `system_auth_node` VALUES (1, 'admin/menu/edit');
INSERT INTO `system_auth_node` VALUES (1, 'admin/menu/del');
INSERT INTO `system_auth_node` VALUES (1, 'admin/menu/forbid');
INSERT INTO `system_auth_node` VALUES (1, 'admin/menu/resume');
INSERT INTO `system_auth_node` VALUES (1, 'admin/node');
INSERT INTO `system_auth_node` VALUES (1, 'admin/node/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/node/save');
INSERT INTO `system_auth_node` VALUES (1, 'admin/sms');
INSERT INTO `system_auth_node` VALUES (1, 'admin/sms/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/user');
INSERT INTO `system_auth_node` VALUES (1, 'admin/user/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/user/auth');
INSERT INTO `system_auth_node` VALUES (1, 'admin/user/add');
INSERT INTO `system_auth_node` VALUES (1, 'admin/user/edit');
INSERT INTO `system_auth_node` VALUES (1, 'admin/user/pass');
INSERT INTO `system_auth_node` VALUES (1, 'admin/user/del');
INSERT INTO `system_auth_node` VALUES (1, 'admin/user/forbid');
INSERT INTO `system_auth_node` VALUES (1, 'admin/user/resume');
INSERT INTO `system_auth_node` VALUES (1, 'admin/verson');
INSERT INTO `system_auth_node` VALUES (1, 'admin/verson/index');
INSERT INTO `system_auth_node` VALUES (1, 'admin/verson/add');
INSERT INTO `system_auth_node` VALUES (1, 'admin/verson/edit');
INSERT INTO `system_auth_node` VALUES (1, 'admin/verson/del');
INSERT INTO `system_auth_node` VALUES (1, 'blog');
INSERT INTO `system_auth_node` VALUES (1, 'blog/article');
INSERT INTO `system_auth_node` VALUES (1, 'blog/article/index');
INSERT INTO `system_auth_node` VALUES (1, 'blog/article/add');
INSERT INTO `system_auth_node` VALUES (1, 'blog/article/edit');
INSERT INTO `system_auth_node` VALUES (1, 'blog/article/del');
INSERT INTO `system_auth_node` VALUES (1, 'blog/article/forbid');
INSERT INTO `system_auth_node` VALUES (1, 'blog/article/resume');
INSERT INTO `system_auth_node` VALUES (1, 'blog/comment');
INSERT INTO `system_auth_node` VALUES (1, 'blog/comment/index');
INSERT INTO `system_auth_node` VALUES (1, 'blog/message');
INSERT INTO `system_auth_node` VALUES (1, 'blog/message/index');
INSERT INTO `system_auth_node` VALUES (1, 'blog/message/del');
INSERT INTO `system_auth_node` VALUES (1, 'blog/notice');
INSERT INTO `system_auth_node` VALUES (1, 'blog/notice/index');
INSERT INTO `system_auth_node` VALUES (1, 'blog/notice/add');
INSERT INTO `system_auth_node` VALUES (1, 'blog/notice/edit');
INSERT INTO `system_auth_node` VALUES (1, 'blog/notice/del');
INSERT INTO `system_auth_node` VALUES (1, 'blog/notice/forbid');
INSERT INTO `system_auth_node` VALUES (1, 'blog/notice/resume');
INSERT INTO `system_auth_node` VALUES (1, 'blog/user');
INSERT INTO `system_auth_node` VALUES (1, 'blog/user/index');
INSERT INTO `system_auth_node` VALUES (1, 'blog/user/add');
INSERT INTO `system_auth_node` VALUES (1, 'blog/user/edit');
INSERT INTO `system_auth_node` VALUES (1, 'blog/user/pass');
INSERT INTO `system_auth_node` VALUES (1, 'blog/user/del');
INSERT INTO `system_auth_node` VALUES (1, 'blog/user/forbid');
INSERT INTO `system_auth_node` VALUES (1, 'blog/user/resume');
INSERT INTO `system_auth_node` VALUES (1, 'demo');
INSERT INTO `system_auth_node` VALUES (1, 'demo/plugs');
INSERT INTO `system_auth_node` VALUES (1, 'demo/plugs/file');
INSERT INTO `system_auth_node` VALUES (1, 'demo/plugs/region');
INSERT INTO `system_auth_node` VALUES (1, 'demo/plugs/editor');
INSERT INTO `system_auth_node` VALUES (1, 'demo/socket');
INSERT INTO `system_auth_node` VALUES (1, 'demo/socket/index');
INSERT INTO `system_auth_node` VALUES (1, 'wechat');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/config');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/config/index');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/config/pay');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/fans');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/fans/index');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/fans/back');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/fans/backadd');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/fans/tagset');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/fans/backdel');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/fans/tagadd');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/fans/tagdel');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/fans/sync');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/keys');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/keys/index');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/keys/add');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/keys/edit');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/keys/del');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/keys/forbid');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/keys/resume');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/keys/subscribe');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/keys/defaults');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/menu');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/menu/index');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/menu/edit');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/menu/cancel');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/news');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/news/index');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/news/select');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/news/image');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/news/add');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/news/edit');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/news/del');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/news/push');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/tags');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/tags/index');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/tags/add');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/tags/edit');
INSERT INTO `system_auth_node` VALUES (1, 'wechat/tags/sync');
INSERT INTO `system_auth_node` VALUES (2, 'admin');
INSERT INTO `system_auth_node` VALUES (2, 'admin/auth');
INSERT INTO `system_auth_node` VALUES (2, 'admin/auth/index');
INSERT INTO `system_auth_node` VALUES (2, 'admin/classify');
INSERT INTO `system_auth_node` VALUES (2, 'admin/classify/index');
INSERT INTO `system_auth_node` VALUES (2, 'admin/classify/add');
INSERT INTO `system_auth_node` VALUES (2, 'admin/classify/edit');
INSERT INTO `system_auth_node` VALUES (2, 'admin/verson');
INSERT INTO `system_auth_node` VALUES (2, 'admin/verson/index');
INSERT INTO `system_auth_node` VALUES (2, 'blog');
INSERT INTO `system_auth_node` VALUES (2, 'blog/article');
INSERT INTO `system_auth_node` VALUES (2, 'blog/article/index');
INSERT INTO `system_auth_node` VALUES (2, 'blog/message');
INSERT INTO `system_auth_node` VALUES (2, 'blog/message/index');
INSERT INTO `system_auth_node` VALUES (2, 'blog/notice');
INSERT INTO `system_auth_node` VALUES (2, 'blog/notice/index');
INSERT INTO `system_auth_node` VALUES (2, 'blog/user');
INSERT INTO `system_auth_node` VALUES (2, 'blog/user/index');
INSERT INTO `system_auth_node` VALUES (2, 'demo');
INSERT INTO `system_auth_node` VALUES (2, 'demo/plugs');
INSERT INTO `system_auth_node` VALUES (2, 'demo/plugs/file');
INSERT INTO `system_auth_node` VALUES (2, 'demo/plugs/region');
INSERT INTO `system_auth_node` VALUES (2, 'demo/plugs/editor');

-- ----------------------------
-- Table structure for system_classify
-- ----------------------------
DROP TABLE IF EXISTS `system_classify`;
CREATE TABLE `system_classify`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(11) UNSIGNED DEFAULT 0,
  `name` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '部门名称',
  `sort` int(11) UNSIGNED DEFAULT 0,
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  `status` tinyint(4) UNSIGNED DEFAULT 1,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 80 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of system_classify
-- ----------------------------
INSERT INTO `system_classify` VALUES (61, 64, '独立团', 0, 1511408182, 1);
INSERT INTO `system_classify` VALUES (62, 61, '侦察兵一连', 0, 1511408211, 1);
INSERT INTO `system_classify` VALUES (63, 61, '炮兵一连', 0, 1511408248, 1);
INSERT INTO `system_classify` VALUES (64, 61, '步兵一连', 0, 1511408268, 1);
INSERT INTO `system_classify` VALUES (65, 62, '一排', 0, 1511408303, 1);
INSERT INTO `system_classify` VALUES (66, 73, '是多少', 0, 1537406781, 1);
INSERT INTO `system_classify` VALUES (68, 0, ' 才123412341', 0, 1537431402, 1);
INSERT INTO `system_classify` VALUES (69, 0, '公司', 0, 1537434391, 1);
INSERT INTO `system_classify` VALUES (70, 70, '客户', 0, 1537434403, 1);
INSERT INTO `system_classify` VALUES (71, 72, '56666', 0, 1537448277, 1);
INSERT INTO `system_classify` VALUES (72, 71, '77777', 0, 1537548227, 1);
INSERT INTO `system_classify` VALUES (73, 72, '是非得失', 0, 1537620206, 1);
INSERT INTO `system_classify` VALUES (74, 0, '11', 0, 1537761259, 1);
INSERT INTO `system_classify` VALUES (75, 74, '花生', 0, 1537841224, 1);
INSERT INTO `system_classify` VALUES (76, 69, '第一期', 0, 1537856784, 1);
INSERT INTO `system_classify` VALUES (77, 76, '期房介绍', 0, 1537856792, 1);
INSERT INTO `system_classify` VALUES (78, 78, 'admin', 0, 1537865410, 1);
INSERT INTO `system_classify` VALUES (79, 0, 'www', 0, 1537934434, 1);

-- ----------------------------
-- Table structure for system_config
-- ----------------------------
DROP TABLE IF EXISTS `system_config`;
CREATE TABLE `system_config`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '配置编码',
  `value` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '配置值',
  `create_at` int(11) UNSIGNED DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 233 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of system_config
-- ----------------------------
INSERT INTO `system_config` VALUES (148, 'site_name', 'Weilmanky', 0);
INSERT INTO `system_config` VALUES (149, 'site_copy', 'Weilmanky © 2016~2018', 0);
INSERT INTO `system_config` VALUES (164, 'storage_type', 'local', 0);
INSERT INTO `system_config` VALUES (165, 'storage_qiniu_is_https', '', 0);
INSERT INTO `system_config` VALUES (166, 'storage_qiniu_bucket', '', 0);
INSERT INTO `system_config` VALUES (167, 'storage_qiniu_domain', '', 0);
INSERT INTO `system_config` VALUES (168, 'storage_qiniu_access_key', '', 0);
INSERT INTO `system_config` VALUES (169, 'storage_qiniu_secret_key', '', 0);
INSERT INTO `system_config` VALUES (170, 'storage_qiniu_region', '', 0);
INSERT INTO `system_config` VALUES (173, 'app_name', 'Weilmanky', 0);
INSERT INTO `system_config` VALUES (174, 'app_version', 'V1.2.45', 0);
INSERT INTO `system_config` VALUES (176, 'browser_icon', 'http://weilmanky.cn/static/upload/c325be959d7777c5/3e924ffba81609c7.ico', 0);
INSERT INTO `system_config` VALUES (184, 'wechat_appid', 'wx5fa70dd8a4454368', 0);
INSERT INTO `system_config` VALUES (185, 'wechat_appsecret', '29b6c633587b896acd8aa0e375bf54cd', 0);
INSERT INTO `system_config` VALUES (186, 'wechat_token', 'OA_CMS', 0);
INSERT INTO `system_config` VALUES (187, 'wechat_encodingaeskey', 'fHRwPi3K0Txfn38eQ0HZvObuvKoFlJQhoMq68hiIuVr', 0);
INSERT INTO `system_config` VALUES (188, 'wechat_mch_id', '', 0);
INSERT INTO `system_config` VALUES (189, 'wechat_partnerkey', '', 0);
INSERT INTO `system_config` VALUES (194, 'wechat_cert_key', '', 0);
INSERT INTO `system_config` VALUES (196, 'wechat_cert_cert', '', 0);
INSERT INTO `system_config` VALUES (197, 'tongji_baidu_key', '', 0);
INSERT INTO `system_config` VALUES (198, 'tongji_cnzz_key', '1261854404', 0);
INSERT INTO `system_config` VALUES (199, 'storage_oss_bucket', '', 0);
INSERT INTO `system_config` VALUES (200, 'storage_oss_keyid', '', 0);
INSERT INTO `system_config` VALUES (201, 'storage_oss_secret', '', 0);
INSERT INTO `system_config` VALUES (202, 'storage_oss_domain', '', 0);
INSERT INTO `system_config` VALUES (203, 'storage_oss_is_https', '', 0);
INSERT INTO `system_config` VALUES (204, 'web_site_close', '1', 0);
INSERT INTO `system_config` VALUES (205, 'seo_title', 'Weilmanky', 0);
INSERT INTO `system_config` VALUES (206, 'seo_keywords', 'Weilmanky', 0);
INSERT INTO `system_config` VALUES (207, 'seo_description', 'Weilmanky', 0);
INSERT INTO `system_config` VALUES (208, 'web_site_icp', '', 0);
INSERT INTO `system_config` VALUES (209, 'company_address', '', 0);
INSERT INTO `system_config` VALUES (210, 'company_phone', '', 0);
INSERT INTO `system_config` VALUES (211, 'company_fixed_line', '', 0);
INSERT INTO `system_config` VALUES (212, 'company_qq', '', 0);
INSERT INTO `system_config` VALUES (213, 'company_url', '', 0);
INSERT INTO `system_config` VALUES (214, 'company_email', '', 0);
INSERT INTO `system_config` VALUES (215, 'company_headquarters', '', 0);
INSERT INTO `system_config` VALUES (216, 'company_head', '', 0);
INSERT INTO `system_config` VALUES (217, 'company_head_mobile', '', 1497498198);
INSERT INTO `system_config` VALUES (218, 'company_head_mobile', '', 0);
INSERT INTO `system_config` VALUES (219, 'web_site_logo', 'http://weilmanky.cn/static/upload/842e0df249441aa0/af65c5b3acf6785c.jpg', 0);
INSERT INTO `system_config` VALUES (220, 'seo_title_form', '', 1502265867);
INSERT INTO `system_config` VALUES (221, 'web_site_logo_form', 'http://fx.jooins.com/static/upload/3750a83bb5fda9e2/1efcd75d21d76ca6.png', 1502265867);
INSERT INTO `system_config` VALUES (222, 'web_site_close_form', '1', 1502265867);
INSERT INTO `system_config` VALUES (223, 'web_site_icp_form', '145646415', 1502265867);
INSERT INTO `system_config` VALUES (224, 'seo_keywords_form', '168546535', 1502265867);
INSERT INTO `system_config` VALUES (225, 'seo_description_form', '48646456', 1502265867);
INSERT INTO `system_config` VALUES (226, 'ip_list', '127.0.0.1', 1503207975);
INSERT INTO `system_config` VALUES (227, 'allow_mobile_list', '', 1503207975);
INSERT INTO `system_config` VALUES (228, 'allow_module_list', 'admin,wechat', 1503207975);
INSERT INTO `system_config` VALUES (230, 'wechat_type', 'api', 1537863462);
INSERT INTO `system_config` VALUES (231, 'wechat_thr_appid', '', 1537863462);
INSERT INTO `system_config` VALUES (232, 'wechat_thr_appkey', '', 1537863462);

-- ----------------------------
-- Table structure for system_log
-- ----------------------------
DROP TABLE IF EXISTS `system_log`;
CREATE TABLE `system_log`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ip` char(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '操作者IP地址',
  `node` char(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '当前操作节点',
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '操作人用户名',
  `action` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '操作行为',
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '操作内容描述',
  `create_at` int(11) UNSIGNED NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 132811 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统操作日志表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of system_log
-- ----------------------------
INSERT INTO `system_log` VALUES (132810, '127.0.0.1', 'admin/menu/del', 'admin', '系统管理', '删除菜单', 1537963814);

-- ----------------------------
-- Table structure for system_menu
-- ----------------------------
DROP TABLE IF EXISTS `system_menu`;
CREATE TABLE `system_menu`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) UNSIGNED NOT NULL DEFAULT 0 COMMENT '父id',
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `node` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '节点代码',
  `icon` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '菜单图标',
  `url` varchar(400) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '链接',
  `params` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT '链接参数',
  `target` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '_self' COMMENT '链接打开方式',
  `sort` int(11) UNSIGNED DEFAULT 0 COMMENT '菜单排序',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '状态(0:禁用,1:启用)',
  `create_by` bigint(20) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建人',
  `create_at` int(11) DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `index_system_menu_node`(`node`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 290 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统菜单表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of system_menu
-- ----------------------------
INSERT INTO `system_menu` VALUES (2, 0, '系统管理', '', 'fa fa-windows', '#', '', '_self', 0, 1, 0, 1498201707);
INSERT INTO `system_menu` VALUES (3, 4, '后台首页', '', 'fa  fa-home', 'admin/index/main', '', '_self', 0, 1, 0, 1498201707);
INSERT INTO `system_menu` VALUES (4, 2, '系统配置', '', '', '#', '', '_self', 0, 1, 0, 1498201707);
INSERT INTO `system_menu` VALUES (5, 4, '网站参数', '', 'fa fa-apple', 'admin/config/index', '', '_self', 1, 1, 0, 1498201707);
INSERT INTO `system_menu` VALUES (9, 123, '操作日志', '', '', 'admin/log/index', '', '_self', 50, 1, 0, 2017);
INSERT INTO `system_menu` VALUES (19, 20, '权限管理', '', 'fa fa-user-secret', 'admin/auth/index', '', '_self', 20, 1, 0, 1498201707);
INSERT INTO `system_menu` VALUES (20, 2, '系统权限', '', '', '#', '', '_self', 2, 1, 0, 1498201707);
INSERT INTO `system_menu` VALUES (21, 20, '系统菜单', '', 'glyphicon glyphicon-menu-hamburger', 'admin/menu/index', '', '_self', 30, 1, 0, 1498201707);
INSERT INTO `system_menu` VALUES (22, 20, '节点管理', '', 'fa fa-ellipsis-v', 'admin/node/index', '', '_self', 10, 1, 0, 1498201707);
INSERT INTO `system_menu` VALUES (29, 120, '系统用户', '', 'fa fa-group', 'admin/user/index', '', '_self', 40, 1, 0, 1498201707);
INSERT INTO `system_menu` VALUES (120, 2, '用户管理', '', '', '#', '', '_self', 3, 1, 0, 1498199372);
INSERT INTO `system_menu` VALUES (122, 120, '无级分类', '', '', 'admin/classify/index', '', '_self', 0, 1, 0, 1498199459);
INSERT INTO `system_menu` VALUES (123, 2, '系统管理', '', '', '#', '', '_self', 5, 1, 0, 1498201707);
INSERT INTO `system_menu` VALUES (124, 0, '微信管理', '', 'fa fa-comments', '#', '', '_self', 0, 1, 0, 1498803991);
INSERT INTO `system_menu` VALUES (125, 124, '微信设置', '', '', '#', '', '_self', 0, 1, 0, 1498804114);
INSERT INTO `system_menu` VALUES (126, 125, '微信接口配置', '', '', '/wechat/config/index', '', '_self', 0, 1, 0, 1498804149);
INSERT INTO `system_menu` VALUES (128, 124, '微信粉丝管理', '', '', '#', '', '_self', 0, 1, 0, 1498804233);
INSERT INTO `system_menu` VALUES (129, 128, '粉丝标签', '', '', '/wechat/tags/index', '', '_self', 0, 1, 0, 1498804258);
INSERT INTO `system_menu` VALUES (130, 128, '已关注粉丝', '', '', '/wechat/fans/index', '', '_self', 0, 1, 0, 1498804281);
INSERT INTO `system_menu` VALUES (132, 124, '微信订制', '', '', '#', '', '_self', 0, 1, 0, 1498804331);
INSERT INTO `system_menu` VALUES (133, 132, '微信菜单定制', '', '', '/wechat/menu/index', '', '_self', 0, 1, 0, 1498804362);
INSERT INTO `system_menu` VALUES (134, 132, '关键字管理', '', '', '/wechat/keys/index', '', '_self', 0, 1, 0, 1498804385);
INSERT INTO `system_menu` VALUES (135, 132, '关注自动回复', '', '', '/wechat/keys/subscribe', '', '_self', 0, 1, 0, 1498804411);
INSERT INTO `system_menu` VALUES (136, 132, '无配置默认回复', '', '', '/wechat/keys/defaults', '', '_self', 0, 1, 0, 1498804435);
INSERT INTO `system_menu` VALUES (137, 124, '素材资源管理', '', '', '#', '', '_self', 0, 1, 0, 1498804469);
INSERT INTO `system_menu` VALUES (138, 137, '添加图文', '', '', 'wechat/news/add?id=1', '', '_self', 0, 1, 0, 1498804513);
INSERT INTO `system_menu` VALUES (139, 137, '图文列表', '', '', '/wechat/news/index', '', '_self', 0, 1, 0, 1498804552);
INSERT INTO `system_menu` VALUES (246, 2, '备份管理', '', '', '#', '', '_self', 0, 1, 0, 1505786963);
INSERT INTO `system_menu` VALUES (247, 246, '数据备份', '', '', 'admin/data/index', '', '_self', 0, 1, 0, 1505786984);
INSERT INTO `system_menu` VALUES (248, 246, '数据还原', '', '', 'admin/data/import', '', '_self', 0, 1, 0, 1505786998);
INSERT INTO `system_menu` VALUES (268, 2, '关于系统', '', '', '#', '', '_self', 6, 1, 0, 1508833131);
INSERT INTO `system_menu` VALUES (269, 268, '版本说明', '', '', 'admin/verson/index', '', '_self', 0, 1, 0, 1508833159);
INSERT INTO `system_menu` VALUES (270, 0, '插件案例', '', 'fa fa-hand-pointer-o', '#', '', '_self', 0, 1, 0, 1511404511);
INSERT INTO `system_menu` VALUES (271, 270, '第三方插件', '', '', '#', '', '_self', 0, 1, 0, 1511404538);
INSERT INTO `system_menu` VALUES (272, 271, 'PCAS 省市区', '', '', 'demo/plugs/region', '', '_self', 0, 1, 0, 1511404574);
INSERT INTO `system_menu` VALUES (273, 270, '富文本编辑器', '', '', 'demo/plugs/editor', '', '_self', 0, 1, 0, 1511404605);
INSERT INTO `system_menu` VALUES (274, 270, '内置插件', '', '', '#', '', '_self', 0, 1, 0, 1511404644);
INSERT INTO `system_menu` VALUES (275, 274, '文件上传', '', '', 'demo/plugs/file', '', '_self', 0, 1, 0, 1511404660);
INSERT INTO `system_menu` VALUES (277, 0, '博客管理', '', 'fa fa-mortar-board', '#', '', '_self', 0, 1, 0, 1530935324);
INSERT INTO `system_menu` VALUES (278, 277, '用户管理', '', '', '#', '', '_self', 0, 1, 0, 1530935362);
INSERT INTO `system_menu` VALUES (279, 277, '文章管理', '', '', '#', '', '_self', 0, 1, 0, 1530935493);
INSERT INTO `system_menu` VALUES (280, 277, '公告管理', '', '', '#', '', '_self', 0, 1, 0, 1530935535);
INSERT INTO `system_menu` VALUES (281, 277, '留言管理', '', '', '#', '', '_self', 0, 1, 0, 1530935629);
INSERT INTO `system_menu` VALUES (283, 278, '用户列表', '', '', '/blog/user/index', '', '_self', 0, 1, 0, 1530936455);
INSERT INTO `system_menu` VALUES (285, 281, '留言列表', '', '', '/blog/message/index', '', '_self', 0, 1, 0, 1530936483);
INSERT INTO `system_menu` VALUES (286, 280, '公告列表', '', '', '/blog/notice/index', '', '_self', 0, 1, 0, 1530936501);
INSERT INTO `system_menu` VALUES (287, 279, '文章列表', '', '', '/blog/article/index', '', '_self', 0, 1, 0, 1530936526);
INSERT INTO `system_menu` VALUES (288, 4, '发送短信', '', 'fa fa-modx', '/admin/sms/index', '', '_self', 0, 1, 0, 1532848895);
INSERT INTO `system_menu` VALUES (289, 4, '发送邮件', '', 'fa fa-edge', '/admin/mail/index', '', '_self', 0, 1, 0, 1532848936);

-- ----------------------------
-- Table structure for system_node
-- ----------------------------
DROP TABLE IF EXISTS `system_node`;
CREATE TABLE `system_node`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `node` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '节点代码',
  `title` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '节点标题',
  `is_menu` tinyint(1) UNSIGNED DEFAULT 0 COMMENT '是否可设置为菜单',
  `is_auth` tinyint(1) UNSIGNED DEFAULT 1 COMMENT '是启启动RBAC权限控制',
  `is_login` tinyint(1) UNSIGNED DEFAULT 1 COMMENT '是否启动登录控制',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `index_system_node_node`(`node`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 866 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统节点表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of system_node
-- ----------------------------
INSERT INTO `system_node` VALUES (723, 'admin', '系统管理', 0, 1, 1, 1511366183);
INSERT INTO `system_node` VALUES (724, 'admin/auth', '权限管理', 0, 1, 1, 1511366233);
INSERT INTO `system_node` VALUES (725, 'admin/auth/index', '权限列表', 0, 1, 1, 1511366254);
INSERT INTO `system_node` VALUES (726, 'admin/auth/apply', '权限授权', 0, 1, 1, 1511366256);
INSERT INTO `system_node` VALUES (727, 'admin/log', '日志管理', 0, 1, 1, 1511366273);
INSERT INTO `system_node` VALUES (728, 'admin/menu', '系统菜单', 0, 1, 1, 1511366282);
INSERT INTO `system_node` VALUES (729, 'admin/node', '节点管理', 0, 1, 1, 1511366295);
INSERT INTO `system_node` VALUES (730, 'admin/user', '用户管理', 0, 1, 1, 1511366311);
INSERT INTO `system_node` VALUES (731, 'admin/verson', '版本说明', 0, 1, 1, 1511366321);
INSERT INTO `system_node` VALUES (732, 'wechat', '微信管理', 0, 1, 1, 1511366327);
INSERT INTO `system_node` VALUES (733, 'admin/department', '部门管理', 0, 1, 1, 1511366379);
INSERT INTO `system_node` VALUES (734, 'admin/data', '备份管理', 0, 1, 1, 1511366392);
INSERT INTO `system_node` VALUES (735, 'admin/config', '网站参数', 0, 1, 1, 1511366402);
INSERT INTO `system_node` VALUES (736, 'admin/auth/add', '添加权限', 0, 1, 1, 1511366478);
INSERT INTO `system_node` VALUES (737, 'admin/auth/edit', '编辑权限', 0, 1, 1, 1511366485);
INSERT INTO `system_node` VALUES (738, 'admin/auth/forbid', '禁用权限', 0, 1, 1, 1511366488);
INSERT INTO `system_node` VALUES (739, 'admin/auth/resume', '启用权限', 0, 1, 1, 1511366509);
INSERT INTO `system_node` VALUES (740, 'admin/auth/del', '删除权限', 0, 1, 1, 1511366515);
INSERT INTO `system_node` VALUES (741, 'admin/config/index', '系统配置', 0, 1, 1, 1511366518);
INSERT INTO `system_node` VALUES (742, 'admin/config/file', '存储配置', 0, 1, 1, 1511366536);
INSERT INTO `system_node` VALUES (743, 'admin/data/index', '备份首页', 0, 1, 1, 1511366548);
INSERT INTO `system_node` VALUES (744, 'admin/data/export', '备份数据库', 0, 1, 1, 1511366574);
INSERT INTO `system_node` VALUES (745, 'admin/data/optimize', '优化表', 0, 1, 1, 1511366582);
INSERT INTO `system_node` VALUES (746, 'admin/data/repair', '修复表', 0, 1, 1, 1511366591);
INSERT INTO `system_node` VALUES (747, 'admin/data/import', '还原数据库', 0, 1, 1, 1511366602);
INSERT INTO `system_node` VALUES (748, 'admin/data/del', '删除备份文件', 0, 1, 1, 1511366611);
INSERT INTO `system_node` VALUES (749, 'admin/data/revert', '还原数据库', 0, 1, 1, 1511366619);
INSERT INTO `system_node` VALUES (750, 'admin/department/index', '部门列表', 0, 1, 1, 1511366632);
INSERT INTO `system_node` VALUES (751, 'admin/department/add', '添加部门', 0, 1, 1, 1511366645);
INSERT INTO `system_node` VALUES (752, 'admin/department/edit', '编辑部门', 0, 1, 1, 1511366653);
INSERT INTO `system_node` VALUES (753, 'admin/department/del', '删除部门', 0, 1, 1, 1511366660);
INSERT INTO `system_node` VALUES (754, 'admin/log/index', '日志列表', 0, 1, 1, 1511366661);
INSERT INTO `system_node` VALUES (755, 'admin/log/del', '删除日志', 0, 1, 1, 1511366679);
INSERT INTO `system_node` VALUES (756, 'admin/menu/index', '菜单列表', 0, 1, 1, 1511366686);
INSERT INTO `system_node` VALUES (757, 'admin/menu/add', '添加菜单', 0, 1, 1, 1511366705);
INSERT INTO `system_node` VALUES (758, 'admin/menu/edit', '编辑菜单', 0, 1, 1, 1511366711);
INSERT INTO `system_node` VALUES (759, 'admin/menu/del', '删除菜单', 0, 1, 1, 1511366717);
INSERT INTO `system_node` VALUES (760, 'admin/menu/forbid', '禁用菜单', 0, 1, 1, 1511366729);
INSERT INTO `system_node` VALUES (761, 'admin/menu/resume', '启用菜单', 0, 1, 1, 1511366739);
INSERT INTO `system_node` VALUES (762, 'admin/node/save', '保存节点变更', 0, 1, 1, 1511366749);
INSERT INTO `system_node` VALUES (763, 'admin/node/index', '显示节点列表', 0, 1, 1, 1511366755);
INSERT INTO `system_node` VALUES (764, 'admin/user/index', '用户列表', 0, 1, 1, 1511366759);
INSERT INTO `system_node` VALUES (765, 'admin/user/auth', '授权管理', 0, 1, 1, 1511366790);
INSERT INTO `system_node` VALUES (767, 'admin/user/add', '添加用户', 0, 1, 1, 1511366829);
INSERT INTO `system_node` VALUES (768, 'admin/user/edit', '编辑用户', 0, 1, 1, 1511366835);
INSERT INTO `system_node` VALUES (769, 'admin/user/pass', '修改密码', 0, 1, 1, 1511366841);
INSERT INTO `system_node` VALUES (770, 'admin/user/del', '删除用户', 0, 1, 1, 1511366846);
INSERT INTO `system_node` VALUES (771, 'admin/user/forbid', '禁用用户', 0, 1, 1, 1511366851);
INSERT INTO `system_node` VALUES (772, 'admin/user/resume', '启用用户', 0, 1, 1, 1511366856);
INSERT INTO `system_node` VALUES (773, 'admin/user/upload_user', '导入用户', 0, 1, 1, 1511366865);
INSERT INTO `system_node` VALUES (774, 'admin/verson/index', '版本列表', 0, 1, 1, 1511366870);
INSERT INTO `system_node` VALUES (775, 'admin/verson/add', '添加版本', 0, 1, 1, 1511366915);
INSERT INTO `system_node` VALUES (776, 'admin/verson/edit', '编辑版本', 0, 1, 1, 1511366922);
INSERT INTO `system_node` VALUES (777, 'admin/verson/del', '删除版本', 0, 1, 1, 1511366928);
INSERT INTO `system_node` VALUES (778, 'admin/classify/index', '分类列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (779, 'admin/classify/add', '添加', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (780, 'admin/classify/edit', '编辑', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (781, 'admin/classify/del', '删除', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (782, 'admin/classify', '无极分类', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (783, 'admin/log/export', '导出日志', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (784, 'admin/mail', '发送邮件', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (785, 'admin/mail/index', '发送邮件', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (786, 'admin/sms', '发送短信', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (787, 'admin/sms/index', '发送短信', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (788, 'admin/user/upload', '导入用户', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (789, 'blog', '博客管理', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (790, 'blog/article', '文章管理', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (791, 'blog/article/index', '文章列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (792, 'blog/article/add', '添加文章', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (793, 'blog/article/edit', '编辑文章', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (794, 'blog/article/del', '删除文章', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (795, 'blog/article/forbid', '禁用文章', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (796, 'blog/article/resume', '启用文章', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (797, 'blog/comment', '文章评论', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (798, 'blog/comment/index', '评论列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (799, 'blog/message', '留言管理', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (800, 'blog/message/index', '留言列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (801, 'blog/message/del', '删除留言', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (802, 'blog/notice', '公告管理', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (803, 'blog/notice/index', '公告列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (804, 'blog/notice/add', '添加公告', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (805, 'blog/notice/edit', '编辑公告', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (806, 'blog/notice/del', '删除公告', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (807, 'blog/notice/forbid', '禁用公告', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (808, 'blog/notice/resume', '启用公告', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (809, 'blog/user', '用户管理', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (810, 'blog/user/index', '用户列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (811, 'blog/user/add', '添加用户', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (812, 'blog/user/edit', '编辑用户', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (813, 'blog/user/pass', '修改密码', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (814, 'blog/user/del', '删除用户', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (815, 'blog/user/forbid', '禁用用户', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (816, 'blog/user/resume', '启用用户', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (817, 'demo', '插件案例', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (818, 'demo/plugs', '第三方插件', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (819, 'demo/plugs/file', '文件上传', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (820, 'demo/plugs/region', '省市区', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (821, 'demo/plugs/editor', '富文本', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (826, 'wechat/config', '微信设置', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (827, 'wechat/config/index', '微信接口配置', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (828, 'wechat/config/pay', '微信支付配置', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (829, 'wechat/fans', '微信粉丝', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (830, 'wechat/fans/index', '粉丝列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (831, 'wechat/fans/back', '粉丝黑名单', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (832, 'wechat/fans/backadd', '设置黑名单', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (833, 'wechat/fans/tagset', '设置标签', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (834, 'wechat/fans/backdel', '取消黑名单', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (835, 'wechat/fans/tagadd', '给粉丝增加标签', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (836, 'wechat/fans/tagdel', '移除粉丝标签', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (837, 'wechat/fans/sync', '同步粉丝列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (838, 'wechat/keys', '关键字管理', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (839, 'wechat/keys/index', '关键字列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (840, 'wechat/keys/add', '添加关键字', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (841, 'wechat/keys/edit', '编辑关键字', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (842, 'wechat/keys/del', '删除关键字', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (843, 'wechat/keys/forbid', '禁用关键字', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (844, 'wechat/keys/resume', '启用关键字', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (845, 'wechat/keys/subscribe', '关注默认回复', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (846, 'wechat/keys/defaults', '无配置默认回复', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (847, 'wechat/menu', '微信菜单管理', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (848, 'wechat/menu/index', '显示列表操作', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (849, 'wechat/menu/edit', '微信菜单编辑', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (850, 'wechat/menu/cancel', '取消菜单', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (851, 'wechat/news', '微信图文管理', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (852, 'wechat/news/index', '图文列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (853, 'wechat/news/select', '图文选择器', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (854, 'wechat/news/image', '媒体资源显示', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (855, 'wechat/news/add', '添加图文', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (856, 'wechat/news/edit', '编辑图文', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (857, 'wechat/news/del', '删除用户', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (858, 'wechat/news/push', '推荐图文', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (859, 'wechat/tags', '微信粉丝标签管理', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (860, 'wechat/tags/index', '显示粉丝标签列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (861, 'wechat/tags/add', '添加粉丝标签', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (862, 'wechat/tags/edit', '编辑粉丝标签', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (863, 'wechat/tags/sync', '同步粉丝标签列表', 0, 1, 1, NULL);
INSERT INTO `system_node` VALUES (864, 'blog/article/comment', '文章评论', 0, 1, 1, 1537325751);
INSERT INTO `system_node` VALUES (865, 'blog/message/reply', '回复留言', 0, 1, 1, 1537325760);

-- ----------------------------
-- Table structure for system_sequence
-- ----------------------------
DROP TABLE IF EXISTS `system_sequence`;
CREATE TABLE `system_sequence`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '序号类型',
  `sequence` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '序号值',
  `create_at` int(11) DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `index_system_sequence_unique`(`type`, `sequence`) USING BTREE,
  INDEX `index_system_sequence_type`(`type`) USING BTREE,
  INDEX `index_system_sequence_number`(`sequence`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统序号表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of system_sequence
-- ----------------------------
INSERT INTO `system_sequence` VALUES (1, 'WECHAT-PAY-TEST', '1278911425', 0);
INSERT INTO `system_sequence` VALUES (2, 'WXPAY-OUTER-NO', '943572063331662367', 0);
INSERT INTO `system_sequence` VALUES (3, 'WECHAT-PAY-TEST', '3182272098', 0);
INSERT INTO `system_sequence` VALUES (4, 'WXPAY-OUTER-NO', '886045600945217047', 0);
INSERT INTO `system_sequence` VALUES (5, 'WXPAY-OUTER-NO', '407999990445092123', 0);
INSERT INTO `system_sequence` VALUES (6, 'WECHAT-PAY-TEST', '5245035323', 0);
INSERT INTO `system_sequence` VALUES (7, 'WXPAY-OUTER-NO', '603743476008986853', 0);
INSERT INTO `system_sequence` VALUES (8, 'WXPAY-OUTER-NO', '410385890858945157', 0);
INSERT INTO `system_sequence` VALUES (9, 'WECHAT-PAY-TEST', '5924801630', 0);
INSERT INTO `system_sequence` VALUES (10, 'WXPAY-OUTER-NO', '349935078313042786', 0);
INSERT INTO `system_sequence` VALUES (11, 'WECHAT-PAY-TEST', '3807112376', 0);
INSERT INTO `system_sequence` VALUES (12, 'WXPAY-OUTER-NO', '203403456577066111', 0);

-- ----------------------------
-- Table structure for system_sms_record
-- ----------------------------
DROP TABLE IF EXISTS `system_sms_record`;
CREATE TABLE `system_sms_record`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for system_sms_templete
-- ----------------------------
DROP TABLE IF EXISTS `system_sms_templete`;
CREATE TABLE `system_sms_templete`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `sms_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' COMMENT '短信模板标识',
  `type` tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '1:是短信 2:是微信企业号',
  `templete_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '短信模板名称',
  `templete_content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '短信模板内容',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT '0:启用 1:禁用',
  `create_at` int(20) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `sms_id`(`sms_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for system_user
-- ----------------------------
DROP TABLE IF EXISTS `system_user`;
CREATE TABLE `system_user`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `deparment_id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '0' COMMENT '部门ID',
  `realname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '真实姓名',
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '登录账号',
  `password` char(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '登录密码',
  `mail` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '联系邮箱',
  `phone` bigint(12) UNSIGNED DEFAULT 0 COMMENT '联系手机号',
  `desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '备注说明',
  `login_num` bigint(20) UNSIGNED DEFAULT 0 COMMENT '登录次数',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '状态(0:禁用,1:启用)',
  `authorize` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '所持权限',
  `is_deleted` tinyint(1) UNSIGNED DEFAULT 0 COMMENT '删除状态(1:删除,0:未删)',
  `login_at` int(11) UNSIGNED DEFAULT 0 COMMENT '最后登录时间',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `index_system_user_username`(`phone`) USING BTREE,
  INDEX `is_deleted`(`is_deleted`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10006 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统用户表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of system_user
-- ----------------------------
INSERT INTO `system_user` VALUES (10000, '5', '超级管理员', 'admin', 'f3887b403932739294c99d9af7843126', '', 13100000000, '1', 13053, 1, '2', 0, 1537963514, 1503976031);
INSERT INTO `system_user` VALUES (10003, '0', '测试顶顶顶', 'test', 'bf1e814260c3d7a4c4ecf0902cc45fb8', '', 13000000000, '', 258, 1, '2', 0, 1537952560, 0);

-- ----------------------------
-- Table structure for wechat_fans
-- ----------------------------
DROP TABLE IF EXISTS `wechat_fans`;
CREATE TABLE `wechat_fans`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `appid` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '公众号Appid',
  `unionid` char(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT 'unionid',
  `openid` char(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '用户的标识,对当前公众号唯一',
  `spread_openid` char(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '推荐人OPENID',
  `spread_at` datetime DEFAULT NULL COMMENT '推荐时间',
  `tagid_list` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '标签id',
  `is_black` tinyint(1) UNSIGNED DEFAULT 0 COMMENT '是否为黑名单用户',
  `subscribe` tinyint(1) UNSIGNED DEFAULT 0 COMMENT '用户是否关注该公众号(0:未关注, 1:已关注)',
  `nickname` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '用户的昵称',
  `sex` tinyint(1) UNSIGNED DEFAULT NULL COMMENT '用户的性别,值为1时是男性,值为2时是女性,值为0时是未知',
  `country` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '用户所在国家',
  `province` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '用户所在省份',
  `city` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '用户所在城市',
  `language` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '用户的语言,简体中文为zh_CN',
  `headimgurl` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '用户头像',
  `subscribe_time` bigint(20) UNSIGNED DEFAULT 0 COMMENT '用户关注时间',
  `subscribe_at` datetime DEFAULT NULL COMMENT '关注时间',
  `remark` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '备注',
  `expires_in` bigint(20) UNSIGNED DEFAULT 0 COMMENT '有效时间',
  `refresh_token` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '刷新token',
  `access_token` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '访问token',
  `subscribe_scene` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '扫码关注场景',
  `qr_scene` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '二维码场景值',
  `qr_scene_str` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '二维码场景内容',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `index_wechat_fans_spread_openid`(`spread_openid`) USING BTREE,
  INDEX `index_wechat_fans_openid`(`openid`) USING BTREE,
  INDEX `index_wechat_fans_unionid`(`unionid`) USING BTREE,
  INDEX `index_wechat_fans_is_back`(`is_black`) USING BTREE,
  INDEX `index_wechat_fans_subscribe`(`subscribe`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 89 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '微信粉丝' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of wechat_fans
-- ----------------------------
INSERT INTO `wechat_fans` VALUES (67, 'wx5fa70dd8a4454368', '', 'ohqV50sbeNN2JLv_RsEJSqLGm87Q', '', NULL, '', 0, 1, '开心宝贝', 2, '中国', '', '', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/PiajxSqBRaEKtJtPhaStXTOEcKMPxeDEGd37YknlVEXKLMHiaD9BuYbtm276PyzQGIkk05pXTdABdRiaPdruzBxUw/132', 1504644936, '2017-09-06 04:55:36', '', 0, '', '', 'ADD_SCENE_SEARCH', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (68, 'wx5fa70dd8a4454368', '', 'ohqV50k8-Ll7imeR14yaqNlWWSpc', '', NULL, '', 0, 1, 'Civilians', 1, '中国', '河南', '郑州', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/PiajxSqBRaEI19pbwby5qyHJqGqAu80s6HKGtr6U7DbWLPNYguHz9iazJEVMV1vTuxYWuz4BhLA1ibB61zsRhaGnA/132', 1508361970, '2017-10-19 05:26:10', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (69, 'wx5fa70dd8a4454368', '', 'ohqV50thU9A48rf6NGJJlxi5mkio', '', NULL, '', 0, 1, '李明', 1, '中国', '天津', '南开', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/PiajxSqBRaEJE8Js4C0a68L99mT6NfSkeJEtl6EWLeia6SiawKQnpnoe3n4fQIgBnBKxwKaH6BN13nhuDQyXzKohg/132', 1505526680, '2017-09-16 09:51:20', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (70, 'wx5fa70dd8a4454368', '', 'ohqV50t0U7ZoQdZAxtxM8lsVLYrA', '', NULL, '', 0, 1, '邓远峰', 1, '中国', '广东', '珠海', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/cfwxzPQY6FbtxGQvBgng4MCEB9UrhAmWzDHnknRZYmuQyGkxX6d7yN5z8lw0IaL5gfxP7dC5LYa5K84XKmQbTeyWJWxKFLvz/132', 1534240205, '2018-08-14 17:50:05', '', 0, '', '', 'ADD_SCENE_SEARCH', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (71, 'wx5fa70dd8a4454368', '', 'ohqV50rmEApMu9dQxJ1aFiropk5c', '', NULL, '', 0, 1, '大叔一枚', 1, '中国', '北京', '西城', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/PiajxSqBRaEJVn1nHUQDx3h9ejohiaoRoiaicIKibWsxPagruicEeHln3rbO7rAqnm0cibZv4gjRsE5fCialuxcVswUGQw/132', 1506783302, '2017-09-30 22:55:02', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (72, 'wx5fa70dd8a4454368', '', 'ohqV50tqUeouqW4H2e8AsSzX2dgs', '', NULL, '', 0, 1, 'An李洋\\ud83d\\udc51', 1, '中国', '北京', '海淀', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/C6nnRGnPbvwAn56L0DzribGdaiaUoWgbvedt96ASNUPhyfQI9XfAEPibpycXvLdOLzwNexXNafWkPuJWttY5LDEUQ/132', 1530510740, '2018-07-02 13:52:20', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (73, 'wx5fa70dd8a4454368', '', 'ohqV50lzNeF7IwrIMwMMoZbdNNDk', '', NULL, '', 0, 1, '啊尼璐吖\\ud83e\\udd8c', 2, '中国', '四川', '成都', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/Fxia1Bya7bicztNJLtllXcx0fD3XtdloOsBAxzxas0gMhcu5p4kL5If9UK1NTd4cuL2LCiceLAgA57uoBFlU9QGdhEiarhU2lC3v/132', 1508503778, '2017-10-20 20:49:38', '', 0, '', '', 'ADD_SCENE_SEARCH', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (74, 'wx5fa70dd8a4454368', '', 'ohqV50vt4Yn2kP0148Ic9fY-Tt-M', '', NULL, '104', 0, 1, 'Mr.Chen', 1, '中国', '广东', '深圳', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/5CicEjZJxJcBMQAZP46oxvAaZHDtETXnia2zfqtpcwqgcgd54icFkaaGZJuIjUsY0buDDmicULBxJ4EcrDKXJlGaqLAyqB5MkDJD/132', 1537874014, '2018-09-25 19:13:34', '', 0, '', '', 'ADD_SCENE_PROFILE_CARD', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (75, 'wx5fa70dd8a4454368', '', 'ohqV50mqAqF6ov_Cjf-gLkb6Edj4', '', NULL, '', 0, 1, '路瑶知马礼', 1, '中国', '甘肃', '定西', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/fzqicHCWEYAxEgf6ezGhfUPagdeMhy24J14vk3ZicMxFA2qHBE2o5d9ZjR9MXOBuIEia4siaO3P7DaJcrz6K5XmLdUpazsh5CFXk/132', 1505521637, '2017-09-16 08:27:17', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (76, 'wx5fa70dd8a4454368', '', 'ohqV50iFOZYJiwY7tEYfdpqmAiv8', '', NULL, '', 0, 1, 'w', 1, '中国', '北京', '朝阳', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/fzqicHCWEYAw7xshiaFRLrfIJJTXnKicbsFmBvWnUMibyoS18mqFCX3uvk2AZfmIiclib23S1a6EXM87V2UMF1ekYLY0jiadpicNpXBa/132', 1508635366, '2017-10-22 09:22:46', '', 0, '', '', 'ADD_SCENE_SEARCH', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (77, 'wx5fa70dd8a4454368', '', 'ohqV50ixnoUWh9alGMBJgPTzknJs', '', NULL, '', 0, 1, 'danny', 0, '', '', '', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/5CicEjZJxJcAlhqJBA9CrhxrtAkVMAnXuAAz0IqJcYibQlvxqSyOsqUV0aFKhDNpGIjzjU3gMA1nms9SnkE5Y73oEoyMh1ygAJ/132', 1536203223, '2018-09-06 11:07:03', '', 0, '', '', 'ADD_SCENE_SEARCH', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (78, 'wx5fa70dd8a4454368', '', 'ohqV50u1kov6N-QZUGIGOILoRyhI', '', NULL, '', 0, 1, '乐乐', 1, '中国', '北京', '朝阳', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/fzqicHCWEYAw7xshiaFRLrfALVLAhNyG6R4IJVxN2DJIXA6fariaJc5ztkYJWNQNvtAHnicXQCXzDqTicU6FDSsEH42Dho3hXltXv/132', 1505483264, '2017-09-15 21:47:44', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (79, 'wx5fa70dd8a4454368', '', 'ohqV50rORCIymOipK4gDTVzCakPY', '', NULL, '', 0, 1, '无殇', 2, '澳大利亚', '昆士兰', '黄金海岸', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/RoYWcsf8a4CcgjVfHNibmqicZgddDuLvTWQ0zNJO8ht22tB6QmfK4TRBVqezkovExCDpK0ibX5MMKppL0dia7JeEBe58f80JnmVb/132', 1510118041, '2017-11-08 13:14:01', '', 0, '', '', 'ADD_SCENE_SEARCH', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (80, 'wx5fa70dd8a4454368', '', 'ohqV50mJkex4y15RMVCrKSo2JYSI', '', NULL, '', 0, 1, 'LR', 1, '中国', '北京', '', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/cfwxzPQY6FatTNJ9WvtNOkXlntp7qSVzGF0K6qEd3TFX2AjUYwqkacMiaJzpFG7JiaFxib50e9TAgkvWcxLRpILE1kzKh35SqQC/132', 1506774399, '2017-09-30 20:26:39', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (81, 'wx5fa70dd8a4454368', '', 'ohqV50l1tZQgtOWOKic5UP21VGUw', '', NULL, '', 0, 1, '美丽人生', 2, '中国', '北京', '朝阳', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/ajNVdqHZLLDo8iaY1ibMQMk0IJuEgO8UPIwjic8OSBYSdtPsiam8YdSNKxCrAaSA0Dnh76YAicDzHAmmZhqjy1Fh48icZy6GHKyScFUPAuVGA6GIs/132', 1506761588, '2017-09-30 16:53:08', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (82, 'wx5fa70dd8a4454368', '', 'ohqV50qQeuCKBANO9O7tbroJ9ReU', '', NULL, '', 0, 1, '༺೪ೣོ西厢记网络展览馆೪ൣོ༻', 2, '中国', '北京', '', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/C6nnRGnPbvxezQ1fdjib5O3RhU4IOtarYyVclYZhVaZdZATibmdxOa0BRhlaNBTwEQthXrRwuMUFd0Fibg03kamEH5eNoEL5QgA/132', 1534262213, '2018-08-14 23:56:53', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (83, 'wx5fa70dd8a4454368', '', 'ohqV50it33n5XMJpJmo27ok7gkzE', '', NULL, '', 0, 1, '百盛商城 陈良斌', 1, '中国', '安徽', '滁州', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/fzqicHCWEYAx2Hys2qicISHjuznPNWNdwBboQMBc3V58icRWWk4gZcPwEWQiaZJahxiclUYyuAb3dF4Mn0fsjzpoJEvnG4MCLHd3j/132', 1528092178, '2018-06-04 14:02:58', '', 0, '', '', 'ADD_SCENE_SEARCH', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (84, 'wx5fa70dd8a4454368', '', 'ohqV50qJge7IXtqD81_7abf9qN9c', '', NULL, '', 0, 1, '马博-网站建设', 1, '中国', '北京', '朝阳', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/fzqicHCWEYAyvDJR2LgzfxcIkRtibQkmFtBwBfdwXkRMXlNOfEIK4U0l0l7DjkcK3Y5uWRnWbMxW7uJz416Ip5nf7jK7OEiatc3/132', 1505482562, '2017-09-15 21:36:02', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (85, 'wx5fa70dd8a4454368', '', 'ohqV50hoBuyXO9ob-xRfb3paUiFM', '', NULL, '', 0, 1, '&她不美，却深驻我心', 1, '中国', '甘肃', '陇南', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/5CicEjZJxJcAJfx4kB6jibqUoTgqianTia2DS6FbmYAdCE0awasiaDOCTuKVtqLFUjSV38YnEfqKadlnxpyvddkCxp7hlgOqVNEdB/132', 1532701381, '2018-07-27 22:23:01', '', 0, '', '', 'ADD_SCENE_SEARCH', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (86, 'wx5fa70dd8a4454368', '', 'ohqV50kXRQ6QmCifWmg8KXnN1Cz8', '', NULL, '', 0, 1, '朱海燕', 2, '中国', '北京', '海淀', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/C6nnRGnPbvxfFSrXtP3L9rD1QBIufu8aZ9sL1gF50CY8Lp2pty1RPyDwuhPjWgpoCLzksURtoLw4otPM0BL4qEOHtZ89OOIZ/132', 1527583397, '2018-05-29 16:43:17', '', 0, '', '', 'ADD_SCENE_SEARCH', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (87, 'wx5fa70dd8a4454368', '', 'ohqV50iJtVsBQvJEjIJfvn_V9uqI', '', NULL, '', 0, 1, '机器人联盟招代理--张承松', 1, '中国', '广东', '广州', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/cfwxzPQY6FalrjawHbmia16LLRCMMtABxibicOM7MRhwdaLyzuAOJr4NZHyB8vusVjbDKGuRl26P4dAUqKhcV7kxyzcSzOefQ1ia/132', 1512031443, '2017-11-30 16:44:03', '', 0, '', '', 'ADD_SCENE_QR_CODE', '0', '', 1537943935);
INSERT INTO `wechat_fans` VALUES (88, 'wx5fa70dd8a4454368', '', 'ohqV50lknFsvjn_tkXIlUh2pyz_k', '', NULL, '', 0, 1, '易小文', 2, '中国', '安徽', '宣城', 'zh_CN', 'http://thirdwx.qlogo.cn/mmopen/5CicEjZJxJcDwJiazBeILAUia6fAyqA0j6CzYwlFwwuNqaGx8SkIHBRrTrG6Gr80p3WPxIRxulrThiaVMwicZQaXqZcKBWyLnzrVF/132', 1529731907, '2018-06-23 13:31:47', '', 0, '', '', 'ADD_SCENE_SEARCH', '0', '', 1537943935);

-- ----------------------------
-- Table structure for wechat_fans_tags
-- ----------------------------
DROP TABLE IF EXISTS `wechat_fans_tags`;
CREATE TABLE `wechat_fans_tags`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '标签ID',
  `appid` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '公众号APPID',
  `name` varchar(35) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '标签名称',
  `count` int(11) UNSIGNED DEFAULT NULL COMMENT '总数',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建日期',
  INDEX `index_wechat_fans_tags_id`(`id`) USING BTREE,
  INDEX `index_wechat_fans_tags_appid`(`appid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 105 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '微信会员标签' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of wechat_fans_tags
-- ----------------------------
INSERT INTO `wechat_fans_tags` VALUES (2, 'wx5fa70dd8a4454368', '星标组', 0, 0);
INSERT INTO `wechat_fans_tags` VALUES (100, 'wx5fa70dd8a4454368', '客服', 0, 0);
INSERT INTO `wechat_fans_tags` VALUES (104, 'wx5fa70dd8a4454368', '你好啊', 1, 0);

-- ----------------------------
-- Table structure for wechat_keys
-- ----------------------------
DROP TABLE IF EXISTS `wechat_keys`;
CREATE TABLE `wechat_keys`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` char(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '公众号APPID',
  `type` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '类型，text 文件消息，image 图片消息，news 图文消息',
  `keys` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '关键字',
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '文本内容',
  `image_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '图片链接',
  `voice_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '语音链接',
  `music_title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '音乐标题',
  `music_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '音乐链接',
  `music_image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '音乐缩略图链接',
  `music_desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '音乐描述',
  `video_title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '视频标题',
  `video_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '视频URL',
  `video_desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '视频描述',
  `news_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT '图文ID',
  `sort` bigint(20) UNSIGNED DEFAULT 0 COMMENT '排序字段',
  `status` tinyint(1) UNSIGNED DEFAULT 1 COMMENT '0 禁用，1 启用',
  `create_by` bigint(20) UNSIGNED DEFAULT NULL COMMENT '创建人',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `index_wechat_keys_appid`(`appid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '微信关键字' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of wechat_keys
-- ----------------------------
INSERT INTO `wechat_keys` VALUES (1, '', 'text', 'subscribe', '欢迎关注.', 'http://weilmanky.cn/static/theme/default/img/image.png', '', '音乐标题', '', 'http://weilmanky.cn/static/theme/default/img/image.png', '音乐描述', '视频标题', '', '视频描述', 0, 0, 1, NULL, 1537866627);
INSERT INTO `wechat_keys` VALUES (2, '', 'text', 'default', '客服正在忙，稍等片刻。', 'http://weilmanky.cn/static/theme/default/img/image.png', '', '音乐标题', '', 'http://weilmanky.cn/static/theme/default/img/image.png', '音乐描述', '视频标题', '', '视频描述', 0, 0, 1, NULL, 1537867130);
INSERT INTO `wechat_keys` VALUES (3, '', 'text', '绑定', '你想绑定什么呢？', 'http://weilmanky.cn/static/theme/default/img/image.png', '', '音乐标题', '', 'http://weilmanky.cn/static/theme/default/img/image.png', '音乐描述', '视频标题', '', '视频描述', 0, 0, 1, NULL, 1537867303);
INSERT INTO `wechat_keys` VALUES (4, '', 'image', '图片', '说点什么吧', 'http://qiniu.jooins.com/c94dc5dfe055368b/60a37f7b1915098c.jpg', '', '音乐标题', '', 'http://weilmanky.cn/static/theme/default/img/image.png', '音乐描述', '视频标题', '', '视频描述', 0, 0, 1, NULL, 1537944012);
INSERT INTO `wechat_keys` VALUES (5, '', 'music', '音乐', '说点什么吧', 'http://weilmanky.cn/static/theme/default/img/image.png', '', '音乐标题', 'http://qiniu.jooins.com/0ee1a0fa482517e2/fd4ed05d10a3c385.mp3', 'http://qiniu.jooins.com/d4b3965fecd5f64f/b1650af311a84868.jpg', '毛不易-牧马人', '视频标题', '', '视频描述', 0, 0, 1, NULL, 1537944629);
INSERT INTO `wechat_keys` VALUES (6, '', 'video', '视频', '说点什么吧', 'http://weilmanky.cn/static/theme/default/img/image.png', '', '音乐标题', '', 'http://weilmanky.cn/static/theme/default/img/image.png', '音乐描述', '视频标题', 'http://qiniu.jooins.com/df09f20771de8ba0/3d94869c37216061.mp4', '视频素材.....', 0, 0, 1, NULL, 1537945376);
INSERT INTO `wechat_keys` VALUES (7, '', 'video', '看视频', '说点什么吧', 'http://weilmanky.cn/static/theme/default/img/image.png', '', '音乐标题', '', 'http://weilmanky.cn/static/theme/default/img/image.png', '音乐描述', '视频标题', 'http://qiniu.jooins.com/df09f20771de8ba0/3d94869c37216061.mov', '视频描述333', 0, 0, 1, NULL, 1537945687);
INSERT INTO `wechat_keys` VALUES (8, '', 'voice', '语音', '说点什么吧', 'http://weilmanky.cn/static/theme/default/img/image.png', 'http://qiniu.jooins.com/0ee1a0fa482517e2/fd4ed05d10a3c385.mp3', '音乐标题', '', 'http://weilmanky.cn/static/theme/default/img/image.png', '音乐描述', '视频标题', '', '视频描述', 0, 0, 1, NULL, 1537945861);

-- ----------------------------
-- Table structure for wechat_menu
-- ----------------------------
DROP TABLE IF EXISTS `wechat_menu`;
CREATE TABLE `wechat_menu`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `index` bigint(20) DEFAULT NULL,
  `pindex` bigint(20) UNSIGNED NOT NULL DEFAULT 0 COMMENT '父id',
  `type` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '菜单类型 null主菜单 link链接 keys关键字',
  `name` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '菜单名称',
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '文字内容',
  `sort` bigint(20) UNSIGNED DEFAULT 0 COMMENT '排序',
  `status` tinyint(1) UNSIGNED DEFAULT 1 COMMENT '状态(0禁用1启用)',
  `create_by` bigint(20) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建人',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `index_wechat_menu_pindex`(`pindex`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '微信菜单配置' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of wechat_menu
-- ----------------------------
INSERT INTO `wechat_menu` VALUES (15, 1, 0, 'text', '一级菜单', '请输入内容', 0, 1, 0, '2018-09-26 15:15:42');
INSERT INTO `wechat_menu` VALUES (16, 11, 1, 'text', '三级菜单', '请输入内容', 0, 1, 0, '2018-09-26 15:15:42');
INSERT INTO `wechat_menu` VALUES (17, 12, 1, 'text', '二级菜单', '请输入内容', 1, 1, 0, '2018-09-26 15:15:42');
INSERT INTO `wechat_menu` VALUES (18, 2, 0, 'text', '一级菜单', '请输入内容', 1, 1, 0, '2018-09-26 15:15:42');
INSERT INTO `wechat_menu` VALUES (19, 21, 2, 'text', '二级菜单', '请输入内容', 0, 1, 0, '2018-09-26 15:15:42');
INSERT INTO `wechat_menu` VALUES (20, 3, 0, 'text', '一级菜单', '请输入内容', 2, 1, 0, '2018-09-26 15:15:42');

-- ----------------------------
-- Table structure for wechat_news
-- ----------------------------
DROP TABLE IF EXISTS `wechat_news`;
CREATE TABLE `wechat_news`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `media_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '永久素材MediaID',
  `local_url` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '永久素材显示URL',
  `article_id` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '关联图文ID，用，号做分割',
  `is_deleted` tinyint(1) UNSIGNED DEFAULT 0 COMMENT '是否删除',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `index_wechat_news_artcle_id`(`article_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '微信图文表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of wechat_news
-- ----------------------------
INSERT INTO `wechat_news` VALUES (3, 'EX9liSdWovOhasGZGGONuBPMD5rhTDAItsjVJtLa51I', '', '5', 0, 1537933181, 10000);
INSERT INTO `wechat_news` VALUES (4, 'EX9liSdWovOhasGZGGONuFAbWcP_aIqTiqPVdcTwXqE', '', '6', 0, 1537934791, 10000);

-- ----------------------------
-- Table structure for wechat_news_article
-- ----------------------------
DROP TABLE IF EXISTS `wechat_news_article`;
CREATE TABLE `wechat_news_article`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '素材标题',
  `local_url` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '永久素材显示URL',
  `show_cover_pic` tinyint(4) UNSIGNED DEFAULT 0 COMMENT '是否显示封面 0不显示，1 显示',
  `author` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '作者',
  `digest` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '摘要内容',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '图文内容',
  `content_source_url` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '图文消息原文地址',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '微信素材表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of wechat_news_article
-- ----------------------------
INSERT INTO `wechat_news_article` VALUES (5, '国家一等功臣“隐居”村中37年，只字不提赫赫战功', 'http://qiniu.jooins.com/9e77f70bf4183f1a/08fac69f77245135.jpg', 1, '小六子', '为保守国家机密，37年“隐于市井”', '<p>测试啊啊啊啊啊啊啊啊啊！</p>\n', 'https://www.toutiao.com/a6602010289334387207', 1537934388, 10000);
INSERT INTO `wechat_news_article` VALUES (6, '苏州一对夫妻7万买下车库挖3米深地窖，带老人孩子住10年', 'http://qiniu.jooins.com/1b9d43062ece2785/4f01b3babc2e30e1.jpg', 0, '小六子', '没谁了', '<p>一个小小的8平方米的车库，在不起眼的地方放了一个橱柜，打开橱柜里面的一个小洞，竟然有一条窄窄的一人宽的密道，通过密道再往里面钻，是一个几乎与车库一样大的房间，而这个不为外界所知的秘密小房间里，有一个女孩在休息&hellip;&hellip;</p>\n\n<p>看着像小说里才会出现的场景，却真实地发生在了江苏苏州新天地家园小区里。这里的一家户主，将原本8平方米的车库进行了私自改造，硬是挖出了一个三米深的地窖，夫妻两人带着老母亲和当年只有8岁的女儿住在这个地窖里，一住就是10年，直到女儿长成18岁的大姑娘，还常年蜗居在这个没有窗子，不见光的地窖里。</p>\n\n<h1>7万元买下车库</h1>\n\n<h1>夫妻俩带着老人孩子住了10年</h1>\n\n<p>8月29日中午，扬子晚报紫牛新闻记者来到新天地家园北区33号楼，只见门口空地上有一大堆杂物用油布遮盖着。地窖位于这幢单元楼的底层自行车库内。未拆除的简易卫生间已遮挡起来，其他物品已被清理干净，地窖正开始被填平。尽管已填了不少砖块进去，记者目测地窖的深度仍然在2米以上，同时可以看出，地窖内部墙壁四周的瓷砖贴得十分整齐。</p>\n\n<p>被查处前，车库共住了一家四口人，夫妻俩带着18岁的女儿，还有一位70岁的老母亲。车库上下各放置一张高低床，妈妈和女儿睡在地窖内，男主人和老人睡在上面。女主人姓汤，她告诉记者，他们一家从淮安到苏州务工，做的是铝合金门窗的生意。2006年，他们在新天地家园小区购置了这个总共8平方米的自行车库。</p>\n\n<p>&ldquo;当时花了7万元买下的，&rdquo;据汤女士回忆，进门处搭建了简易卫生间，把厨房移到屋外，一年四季用电磁炉烧饭做菜，算是勉强安置下四口人的&ldquo;吃喝拉撒睡&rdquo;。不过，很快他们发现，生活空间过于狭小，两张高低床一放，似乎连转身的余地都没有了。2008年，这家人开始对车库进行改造，试图扩大实用面积。没想到的是，竟然挖出一个深达3米的地窖，并且地下一层的面积几乎和上面一样大。<img border=\"0\" src=\"http://qiniu.jooins.com/7e9379d35b7d3372/586188debc14b384.jpg\" style=\"max-width:500px\" title=\"image\" /></p>\n', 'https://www.toutiao.com/a6595723803827896846', 1537934791, 10000);

-- ----------------------------
-- Table structure for wechat_news_image
-- ----------------------------
DROP TABLE IF EXISTS `wechat_news_image`;
CREATE TABLE `wechat_news_image`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `md5` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '文件md5',
  `local_url` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '本地文件链接',
  `media_url` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '远程图片链接',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `index_wechat_news_image_md5`(`md5`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '微信服务器图片' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of wechat_news_image
-- ----------------------------
INSERT INTO `wechat_news_image` VALUES (1, 'c856aff2f340fc30661f0ff0acc2bc2a', 'http://qiniu.jooins.com/7e9379d35b7d3372/586188debc14b384.jpg', 'http://mmbiz.qpic.cn/mmbiz_jpg/kaKSLiaZiboBicHYE64u1yEHD932nQkeuCyP3nqz9z9nZMmxB4FHibSCFuWTLjGtiaP49klicJpy8YB7SRCBjs1eNWqA/0', 1537934815);

-- ----------------------------
-- Table structure for wechat_news_media
-- ----------------------------
DROP TABLE IF EXISTS `wechat_news_media`;
CREATE TABLE `wechat_news_media`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `appid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '公众号ID',
  `md5` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '文件md5',
  `type` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '媒体类型',
  `media_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '永久素材MediaID',
  `local_url` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '本地文件链接',
  `media_url` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '远程图片链接',
  `create_at` int(11) UNSIGNED DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '微信素材表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of wechat_news_media
-- ----------------------------
INSERT INTO `wechat_news_media` VALUES (3, 'wx5fa70dd8a4454368', '7aaf1a73d35d4af94b7ac3275ab3c0d2', 'image', 'EX9liSdWovOhasGZGGONuE-86l7j0DOi7X2py2UXUz8', 'http://qiniu.jooins.com/9e77f70bf4183f1a/08fac69f77245135.jpg', 'http://mmbiz.qpic.cn/mmbiz_jpg/kaKSLiaZiboBicHYE64u1yEHD932nQkeuCy220KTYZCWP1yT6hzylWsvTNO4HialFO971mSMGlevd4LQrCbCY1Xf3A/0?wx_fmt=jpeg', 1537933191);
INSERT INTO `wechat_news_media` VALUES (4, 'wx5fa70dd8a4454368', '84ee0fea40d86fcf80bd0b2328638a1c', 'image', 'EX9liSdWovOhasGZGGONuOmO5XAhzkuvksEhFHQS6Bg', 'http://qiniu.jooins.com/1b9d43062ece2785/4f01b3babc2e30e1.jpg', 'http://mmbiz.qpic.cn/mmbiz_jpg/kaKSLiaZiboBicHYE64u1yEHD932nQkeuCyKRlXaWXeaiaGmicPG5LBlM7NMMJiaBiboKweskhjaOPiaazwibDAIQXoSRRA/0?wx_fmt=jpeg', 1537934814);
INSERT INTO `wechat_news_media` VALUES (5, 'wx5fa70dd8a4454368', 'f68fee01d520f47649c16697283fdaaa', 'image', 'EX9liSdWovOhasGZGGONuAo_wmst-6zcJ8wuzC43Qjg', 'http://qiniu.jooins.com/d4b3965fecd5f64f/b1650af311a84868.jpg', 'http://mmbiz.qpic.cn/mmbiz_jpg/kaKSLiaZiboBicHYE64u1yEHD932nQkeuCyyiarKbu6wseR5rTYRbxnUmISQicTME71lG3Ap8Tvo8DOcAiaOiaCrUhPQg/0?wx_fmt=jpeg', 1537944649);

SET FOREIGN_KEY_CHECKS = 1;
